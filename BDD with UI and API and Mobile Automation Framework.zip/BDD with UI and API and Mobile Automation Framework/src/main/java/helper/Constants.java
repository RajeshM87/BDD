package helper;


public class Constants {


	public final static String userName = "standard_user";
	public final static String password = "secret_sauce";
	
	public final static long explicitWait = 10000;
	public final static long impliciteWait = 10000;
	
	public static String getUsername() {
		return userName;
	}
	public static String getPassword() {
		return password;
	}
	public static long getExplicitwait() {
		return explicitWait;
	}
	public static long getImplicitewait() {
		return impliciteWait;
	}
	
}
