package com.apiClasses;

import com.qa.util.APIBaseTest;
import helper.AllureLogger;
import io.restassured.response.Response;

import java.util.logging.Level;

import static io.restassured.RestAssured.given;

public class DeleteBooking extends APIBaseTest {

	public void deleteBookingIDs() throws Exception{

		AllureLogger.logToAllure("Starting the test to delete booking details");
		/*******************************************************
		 * Send a DELETE request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
		//To get the auth token
		String newAuthToken = AuthToken.post_CreateAuth();
		AllureLogger.logToAllure("Auth token is : "+newAuthToken);
		String cookieValue = "token="+newAuthToken;
		
		CreateBooking createBooking = new CreateBooking();

		String IDtoDelete = createBooking.newID;
		AllureLogger.logToAllure("New Booking ID created is : "+IDtoDelete);
		AllureLogger.logToAllure("Booking ID to be deleted is : "+IDtoDelete);
		
		//Sending the GET request for a specific booking id and receiving the response
		AllureLogger.logToAllure("Sending the GET request for a specific booking id and receiving the response");
		Response response = given().
				spec(requestSpec).
				header("Content-Type", "application/json").
				header("Cookie", cookieValue).
				pathParam("id", IDtoDelete).
			when().
				delete("/booking/{id}");
		
		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 201 as this is a Delete request");
		AllureLogger.logToAllure("HTTP Status Code : "+response.statusCode());
		response.then().assertThat().statusCode(201);

		//To log the response to report
		logResponseAsString(response);
		LOGGER.log(Level.INFO,"HTTP Status Code : "+response.statusCode());
		LOGGER.log(Level.INFO,"Delete Operation performed successfully");
		
	}
}
