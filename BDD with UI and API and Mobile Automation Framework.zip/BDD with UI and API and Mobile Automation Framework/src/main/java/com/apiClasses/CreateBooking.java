package com.apiClasses;

import com.pojoClasses.BookingDates;
import com.pojoClasses.BookingDetails;
import com.qa.util.APIBaseTest;
import com.qa.util.ExcelDataAccess;
import helper.AllureLogger;
import io.restassured.response.Response;

import java.util.logging.Level;

import static io.restassured.RestAssured.given;

public class CreateBooking extends APIBaseTest {
	
	public static String newID = "";
	public static String FirstName;
	public static String LastName;
	public static String TotalPrice;
	public static String DepositPaid;
	public static String CheckIn;
	public static String CheckOut;
	public static String AdditionalNeeds;
	
	public void createNewBooking(String TCID) throws Exception{
		
		AllureLogger.logToAllure("Starting the test to create new details");
		/*******************************************************
		 * Send a POST request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
		
		//Sending the GET request for a specific booking id and receiving the response
		AllureLogger.logToAllure("Posting a new booking detail");

		//To get the auth token
		String newAuthToken = AuthToken.post_CreateAuth();
		AllureLogger.logToAllure("Auth token is : "+ newAuthToken);
		LOGGER.log(Level.INFO,"Auth token is : "+ newAuthToken);

		ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", "APITestData");
		testdata.setDatasheetName("Booking");

		int rowNo = testdata.getRowCount(TCID, 0);

		FirstName = testdata.getValue(rowNo, "FirstName");
		LastName = testdata.getValue(rowNo, "LastName");
		TotalPrice = testdata.getValue(rowNo, "TotalPrice");
		DepositPaid = testdata.getValue(rowNo, "DepositPaid");
		CheckIn = testdata.getValue(rowNo, "CheckIn");
		CheckOut = testdata.getValue(rowNo, "CheckOut");
		AdditionalNeeds = testdata.getValue(rowNo, "AdditionalNeeds");
		
		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setFirstname(FirstName);
		bookingDetails.setLastname(LastName);
		bookingDetails.setTotalprice(Integer.parseInt(TotalPrice));
		bookingDetails.setDepositpaid(Boolean.parseBoolean(DepositPaid));
		bookingDetails.setAdditionalneeds(AdditionalNeeds);
		
		BookingDates bookingDates = new BookingDates();
		bookingDates.setCheckin(CheckIn);
		bookingDates.setCheckout(CheckOut);
		bookingDetails.setBookingdates(bookingDates);
				
		AllureLogger.logToAllure("Sending the POST request to create new booking");
		Response response = given().
								spec(requestSpec).
								contentType("application/json").
					            body(bookingDetails).log().body().
					        when().
					        	post("/booking");
		
		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200");
		response.then().spec(responseSpec);		

		//To log the response to report
		logResponseAsString(response);
		
		
		//To get the newly created booking id
		//System.out.println(response.then().extract().path("bookingid"));
		newID = response.then().extract().path("bookingid").toString();

		AllureLogger.logToAllure("Retrieved booking id : "+response.then().extract().path("bookingid"));
		AllureLogger.logToAllure("HTTP Status Code : "+response.statusCode());
		LOGGER.log(Level.INFO,"HTTP Status Code : "+response.statusCode());
		LOGGER.log(Level.INFO,"Create Operation performed successfully");
		
	}	
}
