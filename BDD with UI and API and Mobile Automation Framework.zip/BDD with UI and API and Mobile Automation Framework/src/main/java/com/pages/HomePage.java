package com.pages;

import java.io.ByteArrayInputStream;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.objrepository.HomePageObjRepo;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.qa.util.GenericWrappers;

import helper.WaitHelper;
import io.qameta.allure.Allure;
import com.qa.util.FrameworkException;

public class HomePage extends GenericWrappers {
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	    		
	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);		
	}
	UIConfig uiconfig = new UIConfig(driver);
	public Properties properties = uiconfig.getenvproperties(); 	
	
	// Method to click on 'Add To Cart' button
		public void clickOnAddToCart() {
			try {				
				//WebDriverWait wait = new WebDriverWait(driver,5);
				//wait.until(ExpectedConditions.visibilityOf(homepageobjrepo.productstitle));
				WebElement addtocart = driver.findElement(HomePageObjRepo.addtocart);
				clickByElement(addtocart, driver);
				LOGGER.log(Level.INFO, "Clicked on Add To Order button successfully");
				Allure.addAttachment("Clicked on Add To Order button successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			} catch (Exception e) {				
				throw new FrameworkException("Home Page", "Error in clicking on 'Add To Order' button in Home Page");				
			}
		}

	// Method to click on 'Shopping Cart' link
		public void clickOnShoppingCart() {				
			try {	
				WebElement shoppingcart = driver.findElement(HomePageObjRepo.shoppingcart);
				clickByElement(shoppingcart, driver);
				LOGGER.log(Level.INFO, "Clicked on Shopping Cart link successfully");		
				Allure.addAttachment("Clicked on Shopping Cart link successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
				 
			} catch (Exception e) {				
				throw new FrameworkException("Home Page", "Error in clicking on 'Shopping Cart' link in Home Page");				
			}
		}

		
}
