package com.pages;

import com.objrepository.MobileObjRepo;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.qa.util.ConfigReader;
import com.qa.util.GenericWrappers;
import helper.WaitHelper;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import org.json.simple.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.Properties;
import java.util.logging.Logger;

public class MobileActions extends GenericWrappers{

	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	JSONObject jsonObject = null;
	private final static Logger LOGGER =
			Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	ConfigReader configReader = new ConfigReader();
	MobileObjRepo mobileObjRepo = new MobileObjRepo();

	public MobileActions(AppiumDriver<MobileElement> driver){
		super(driver);
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);
		properties = configReader.init_prop("config.properties");
	}

	//public Properties properties = getenvproperties();

	public void clickOnTextPreference(){
		WebElement txt_preference = driver.findElement(MobileObjRepo.txt_preference);
		try {
			clickByElement(txt_preference,driver);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void clickOnTextPreferenceXML(){
		WebElement txt_preference_xml = driver.findElement(MobileObjRepo.txt_preference_xml);
		try {
			clickByElement(txt_preference_xml, driver);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void clickOnTextListPreference(){
		WebElement txt_preference_list = driver.findElement(MobileObjRepo.txt_preference_list);
		try {
			clickByElement(txt_preference_list, driver);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clickOnFirstTextButton(){
		WebElement first_txt_button = driver.findElement(MobileObjRepo.firsttxt_preference_list);
		try {
			clickByElement(first_txt_button, driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnTextButton(){
		WebElement txt_button = driver.findElement(MobileObjRepo.btn_text);
		try {
			clickByElement(txt_button, driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterText(){
		WebElement inp_button;
		if(properties.getProperty("os").equalsIgnoreCase("ios"))
			inp_button = driver.findElement(MobileObjRepo.inp_text_ios);
		else
			inp_button = driver.findElement(MobileObjRepo.inp_text_android);

		try {
			enterByElement(inp_button, "Testing." ,driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
