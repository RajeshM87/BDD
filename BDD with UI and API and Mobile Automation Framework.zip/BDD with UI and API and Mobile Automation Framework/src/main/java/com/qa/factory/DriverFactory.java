package com.qa.factory;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.qa.util.ConfigReader;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.RemoteWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {

	public static WebDriver driver;
	String seleniumHub = "192.168.43.223";
	String seleniumHubPort = "5566";
	DesiredCapabilities capability;

	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

	public static void startEmulator() throws IOException, InterruptedException
	{

		Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\startEmulator.bat");
		Thread.sleep(6000);
	}

	/**
	 * This method is used to initialize the thread local driver on the basis of given
	 * browser
	 * 
	 * @param browser
	 * @return this will return tldriver.
	 */
	
	public WebDriver init_driver(String browser) {

		LOGGER.log(Level.INFO, "Browser value is: " + browser);
		
		if (browser.equals("chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--ignore-certificate-errors");
			WebDriverManager.chromedriver().setup();
			tlDriver.set(new ChromeDriver(options));
		} else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			tlDriver.set(new FirefoxDriver());
		} else if (browser.equals("edge")) {
		WebDriverManager.edgedriver().setup();
		tlDriver.set(new EdgeDriver());
		}
		else if (browser.equals("grid")) {
			capability = DesiredCapabilities.chrome();
	        capability.setBrowserName("chrome");
	        capability.setPlatform(Platform.WIN10);
			WebDriverManager.seleniumServerStandalone().setup();
			URL remote_grid = null;
			try {
				remote_grid = new URL("http://" + seleniumHub + ":" + seleniumHubPort + "/wd/hub");
				driver = new RemoteWebDriver(remote_grid, capability);
			} catch (MalformedURLException e) {				
				e.getMessage();
			}			
		}
		else {
			LOGGER.log(Level.INFO, "Please pass the correct browser value: " + browser);			
		}
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();
	}

	/**
	 * this is used to get the driver with ThreadLocal
	 * 
	 * @return
	 */
	public static synchronized WebDriver getDriver() {
		return tlDriver.get();
	}

	/**
	 * This method is used to initialize the android driver
	 * @param
	 *           platform = local => execute locally
	 *           platform = remote => execute on browserstack
	 * @return
	 */
	public WebDriver init_mobile_driver(String platform) throws IOException, InterruptedException {
		capability = new DesiredCapabilities();
		ConfigReader configReader = new ConfigReader();
		Properties prop_config = configReader.init_prop("config.properties");
		Properties prop=null;
		if(prop_config.getProperty("os").equalsIgnoreCase("Android"))
			prop = configReader.init_prop("mobile_android.properties");
		if(prop_config.getProperty("os").equalsIgnoreCase("iOS"))
			prop = configReader.init_prop("mobile_ios.properties");

		if (platform.equalsIgnoreCase("local")) {
			File appDir = new File("src");
			File app = new File(appDir, prop.getProperty("LOCAL_APP_NAME"));
			String device=(String) prop.get("LOCAL_DEVICE_NAME");

			//String device= System.getProperty("deviceName");
			if(device.contains("emulator"))
			{
				startEmulator();
			}

			capability.setCapability(MobileCapabilityType.DEVICE_NAME, prop.getProperty("LOCAL_DEVICE_NAME"));
			capability.setCapability(MobileCapabilityType.AUTOMATION_NAME, prop.getProperty("LOCAL_AUTOMATION_NAME"));// new
			capability.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());

			try {
				if(prop_config.getProperty("os").equalsIgnoreCase("Android"))
					driver = new AndroidDriver<AndroidElement>(new URL(prop.getProperty("LOCAL_SERVER_URL")), capability);
				if(prop_config.getProperty("os").equalsIgnoreCase("iOS"))
					driver = new IOSDriver<>(new URL(prop.getProperty("LOCAL_SERVER_URL")), capability);
				//tlDriver.set(driver);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if (platform.equalsIgnoreCase("remote")) {
			// Set your access credentials
			capability.setCapability("browserstack.user", prop.getProperty("USER_NAME"));
			capability.setCapability("browserstack.key", prop.getProperty("USER_KEY"));

			// Set URL of the application under test
			capability.setCapability("app", prop.getProperty("APP_URL"));

			// Specify device and os_version for testing
			capability.setCapability("device", prop.getProperty("DEVICE_NAME"));
			if(prop_config.getProperty("os").equalsIgnoreCase("iOS"))
				capability.setCapability("Platform", prop.getProperty("Platform"));
			else
				capability.setCapability("os_version", prop.getProperty("OS_VERSION"));
			// Set other BrowserStack capabilities
			capability.setCapability("project", "First Java Project");
			capability.setCapability("build", "browserstack-build-1");
			capability.setCapability("name", "Date>");

			// Initialise the remote Webdriver using BrowserStack remote URL
			// and desired capabilities defined above
			try {
				if(prop_config.getProperty("os").equalsIgnoreCase("Android"))
					driver = new AndroidDriver<AndroidElement>(new URL(prop.getProperty("SERVER_URL")), capability);
				if(prop_config.getProperty("os").equalsIgnoreCase("iOS"))
					driver = new IOSDriver<>(new URL(prop.getProperty("SERVER_URL")), capability);
				//tlDriver.set(driver);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return getAppiumDriver();

	}
	/**
	 * this is used to get the appium driver
	 *
	 * @return
	 */
	public static WebDriver getAppiumDriver() {
		return driver;
	}
}
