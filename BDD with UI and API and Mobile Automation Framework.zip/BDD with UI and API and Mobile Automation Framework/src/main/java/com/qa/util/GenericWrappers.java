package com.qa.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GenericWrappers{

	public WebDriver driver;
	private static int waittime = 1000;
	private static int timecount = 0;
	private int maxtimecount = 60000;
	private int maxtimecounter = 120;
	public Properties properties = null;
	ConfigReader configReader = new ConfigReader();
	
	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	public GenericWrappers(WebDriver driver){
		//ReusableLibrary createorder = new ReusableLibrary(DriverFactory.getDriver());
		this.driver = driver;			
	}

	public Properties getenvproperties() {
		//String environment = System.getenv("env");
		properties = configReader.init_prop("config.properties");
		String environment = properties.getProperty("env");
		LOGGER.log(Level.INFO, "Environment value:" + environment);

		if(environment.equals("uat")) {
			properties = configReader.init_prop("uat.properties");
			LOGGER.log(Level.INFO, "Environment value set as: UAT");
		} else if(environment.equals("acp")) {
			properties = configReader.init_prop("acp.properties");
			LOGGER.log(Level.INFO, "Environment value set as: ACP");
		}
		return properties;
	}

	/**
	 * This method will enter the value to the text field using id attribute to locate
	 * 
	 * @param idValue - id of the webelement
	 * @param data - The data to be sent to the webelement
	 * 
	 * @throws Exception 
	 * @throws IOException 
	 * @throws COSVisitorException 
	 */
	public boolean enterById(String idValue, String data, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		try {
			webdriver.findElement(By.id(idValue)).clear();
			webdriver.findElement(By.id(idValue)).sendKeys(data);	
			LOGGER.log(Level.INFO, "The data: "+data+" entered successfully in field :"+idValue);
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The data: "+data+" could not be entered in the field :"+idValue);
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}


	/**
	 * This method will enter the value to the text field using name attribute to locate
	 * 
	 * @param nameValue - name of the webelement
	 * @param data - The data to be sent to the webelement
	 * @throws Exception 
	 * 
	 * @throws IOException 
	 * @throws COSVisitorException 
	 */
	public boolean enterByName(String nameValue, String data, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try {
			webdriver.findElement(By.name(nameValue)).clear();
			webdriver.findElement(By.name(nameValue)).sendKeys(data);	
			LOGGER.log(Level.INFO, "The data: "+data+" entered successfully in field :");
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The data: "+data+" could not be entered in the field :");
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will enter the value to the text field using Xpath attribute to locate
	 * 
	 * @param XpathValue - Xpath of the webelement
	 * @param data - The data to be sent to the webelement
	 * @throws Exception 
	 * 
	 * @throws IOException 
	 * @throws COSVisitorException 
	 */
	public boolean enterByXpath(String XpathValue, String data, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try {
			webdriver.findElement(By.xpath(XpathValue)).clear();
			webdriver.findElement(By.xpath(XpathValue)).sendKeys(data);	
			LOGGER.log(Level.INFO, "The data: "+data+" entered successfully in field :"+XpathValue);
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The data: "+data+" could not be entered in the field :"+XpathValue);
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}
	
	public boolean enterByElement(WebElement ElementValue, String data, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try {
			//new WebDriverWait(webdriver, 3).until(ExpectedConditions.elementToBeClickable(ElementValue));
			ElementValue.clear();
			ElementValue.sendKeys(data);	
			LOGGER.log(Level.INFO, "The data: "+data+" entered successfully in field :"+ElementValue);
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The data: "+data+" could not be entered in the field :"+ElementValue);
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public boolean enterByXpathWithEnter(String idValue, String data, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		try {
			webdriver.findElement(By.xpath(idValue)).clear();
			webdriver.findElement(By.xpath(idValue)).sendKeys(data, Keys.ENTER);	
			LOGGER.log(Level.INFO, "The data: "+data+" entered successfully in field :"+idValue);
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The data: "+data+" could not be entered in the field :"+idValue);
			throw new Exception("TestCase Stop");

		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}


	/**
	 * This method will verify the title of the browser 
	 * @param title - The expected title of the browser
	 * @throws Exception 
	 * 
	 */
	public boolean verifyTitle(String title, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		try{
			if (driver.getTitle().equalsIgnoreCase(title)){
				LOGGER.log(Level.INFO, "The title of the page matches with the value :"+title);
				bReturn = true;
			}else
				LOGGER.log(Level.INFO, "The title of the page:"+driver.getTitle()+" did not match with the value :"+title);

		}catch (Exception e) {
			LOGGER.log(Level.INFO, "The title did not match");
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}

		return bReturn;
	}

	/**
	 * This method will verify the given text
	 * @param xpath - The locator of the object in xpath
	 * @param text  - The text to be verified
	 * @throws Exception 
	 * 
	 */
	public boolean verifyTextByXpath(String xpath, String text, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		String sText = webdriver.findElement(By.xpath(xpath)).getText();
		if (webdriver.findElement(By.xpath(xpath)).getText().trim().equalsIgnoreCase(text)){
			LOGGER.log(Level.INFO, "The text: "+sText+" matches with the value :"+text);
			bReturn = true;
		}else{
			LOGGER.log(Level.INFO, "The text: "+sText+" did not match with the value :"+text);
			throw new Exception("TestCase Stop");
		}
		return bReturn;
	}

	/**
	 * This method will verify the given text
	 * @param xpath - The locator of the object in xpath
	 * @param text  - The text to be verified
	 * @throws Exception 
	 * 
	 */
	public boolean verifyTextContainsByXpath(String xpath, String text, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		String sText = webdriver.findElement(By.xpath(xpath)).getText();
		if (webdriver.findElement(By.xpath(xpath)).getText().trim().contains(text)){
			LOGGER.log(Level.INFO, "The text: "+sText+" contains the value :"+text);
			bReturn = true;
		}else{
			LOGGER.log(Level.INFO, "The text: "+sText+" did not contain the value :"+text);
			throw new Exception("TestCase Stop");
		}


		return bReturn;
	}

	public boolean verifyTextContainsById(String idValue, String text, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		String sText = webdriver.findElement(By.id(idValue)).getText();
		if (webdriver.findElement(By.id(idValue)).getText().trim().contains(text)){
			LOGGER.log(Level.INFO, "The text: "+sText+" contains the value :"+text);
			bReturn = true;
		}else{
			LOGGER.log(Level.INFO, "The text: "+sText+" did not contain the value :"+text);
			throw new Exception("TestCase Stop");
		}


		return bReturn;
	}

	/**
	 * This method will click the element using id as locator
	 * @param id  The id (locator) of the element to be clicked
	 * @throws Exception 
	 * 
	 */
	public boolean clickById(String id, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			webdriver.findElement(By.id(id)).click();
			LOGGER.log(Level.INFO, "The element with id: "+id+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with id: "+id+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will click the element using id as locator
	 * @param id  The id (locator) of the element to be clicked
	 * @throws Exception 
	 * 
	 */
	public boolean clickByClassName(String classVal, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			webdriver.findElement(By.className(classVal)).click();
			LOGGER.log(Level.INFO, "The element with class Name: "+classVal+" is clicked.");
			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with class Name: "+classVal+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}
	/**
	 * This method will click the element using name as locator
	 * @param name  The name (locator) of the element to be clicked
	 * @throws Exception 
	 * 
	 */
	public boolean clickByName(String name, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.name(name)));

			webdriver.findElement(By.name(name)).click();
			LOGGER.log(Level.INFO, "The element with name: "+name+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with name: "+name+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will click the element using link name as locator
	 * @param name  The link name (locator) of the element to be clicked
	 * 
	 * @throws Exception 
	 */
	public boolean clickByLink(String name, WebDriver webdriver){
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.linkText(name)));
			webdriver.findElement(By.linkText(name)).click();
			LOGGER.log(Level.INFO, "The element with link name: "+name+" is clicked.");
			
			//	alertAccept();

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with link name: "+name+" could not be clicked.");
			try {
				throw new Exception("Stop the TESt");
			} catch (Exception e1) {				
				e1.printStackTrace();
			}
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}
	
	public boolean clickByLinkNoSnap(String name, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.linkText(name)));
			webdriver.findElement(By.linkText(name)).click();
			LOGGER.log(Level.INFO, "The element with link name: "+name+" is clicked.");	

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with link name: "+name+" could not be clicked.");
			throw new Exception("Stop the TESt");
		}
		return bReturn;
	}

	/**
	 * This method will click the element using Partial link name as locator
	 * @param name  The link name (locator) of the element to be clicked
	 * 
	 * @throws Exception 
	 */
	public boolean clickByPartialLink(String name, WebDriver webdriver) throws Exception{
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.partialLinkText(name)));
			webdriver.findElement(By.partialLinkText(name)).click();
			LOGGER.log(Level.INFO, "The element with link name: "+name+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with link name: "+name+" could not be clicked.");
			throw new Exception("Stop the TESt");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will click the element using xpath as locator
	 * @param senders  The xpath (locator) of the element to be clicked
	 * @throws Exception 
	 * 
	 */
	public boolean clickByXpath(String xpathVal, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.xpath(xpathVal)));
			webdriver.findElement(By.xpath(xpathVal)).click();
			LOGGER.log(Level.INFO, "The element : "+xpathVal+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with xpath: "+xpathVal+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}finally {
				takeSnap(webdriver);
		}
		return bReturn;
	}
	
	public boolean clickByXpathNoSnap(String xpathVal, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.xpath(xpathVal)));
			webdriver.findElement(By.xpath(xpathVal)).click();
			LOGGER.log(Level.INFO, "The element : "+xpathVal+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with xpath: "+xpathVal+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}
		return bReturn;
	}
	
	/**
	 * This method will click the element using xpath as locator
	 * @param xpathVal  The xpath (locator) of the element to be clicked
	 * @throws Exception 
	 * 
	 */
	public boolean clickByElement(WebElement ElementVal, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			//new WebDriverWait(webdriver, 3).until(ExpectedConditions.elementToBeClickable(ElementVal));
			ElementVal.click();
			LOGGER.log(Level.INFO, "The element : "+ElementVal+" is clicked.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element: "+ElementVal+" could not be clicked.");
			throw new Exception("TestCase Stop");
		}finally {
				takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will mouse over on the element using xpath as locator
	 * @param xpathVal  The xpath (locator) of the element to be moused over
	 * @throws Exception 
	 * 
	 */
	public boolean mouseOverByXpath(String xpathVal, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new Actions(driver).moveToElement(webdriver.findElement(By.xpath(xpathVal))).build().perform();
			LOGGER.log(Level.INFO, "The mouse over by xpath : "+xpathVal+" is performed.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The mouse over by xpath : "+xpathVal+" could not be performed.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will mouse over on the element using link name as locator
	 * @param xpathVal  The link name (locator) of the element to be moused over
	 * @throws Exception 
	 * 
	 */
	public boolean mouseOverByLinkText(String linkName, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new Actions(driver).moveToElement(webdriver.findElement(By.linkText(linkName))).build().perform();
			LOGGER.log(Level.INFO, "The mouse over by link : "+linkName+" is performed.");

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The mouse over by link : "+linkName+" could not be performed.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public String getTextByXpath(String xpathVal, WebDriver webdriver) throws Exception{
		String bReturn = "";
		try{
			bReturn = webdriver.findElement(By.xpath(xpathVal)).getText();
			LOGGER.log(Level.INFO, bReturn);
		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with xpath: "+xpathVal+" could not be found.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn; 
	}

	public String getAttributeById(String idValue, String value, WebDriver webdriver) throws Exception{
		String bReturn = "";
		try{
			bReturn = webdriver.findElement(By.id(idValue)).getAttribute(value);
		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The element with Id: "+idValue+" could not be found.");
			throw new Exception("TestCase Stop");
		}finally {
			takeSnap(webdriver);
		}
		return bReturn; 
	}

	public boolean switchToFrame(String nameOrId, WebDriver webdriver) {
		boolean bReturn = false;
		try {
			driver.switchTo().frame(nameOrId);

			bReturn = true;
		} catch (WebDriverException e1) {
			e1.printStackTrace();
		}finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public boolean switchToDefault(WebDriver webdriver) {
		boolean bReturn = false;
		try {
			driver.switchTo().defaultContent(); 
			bReturn = true;
		} catch (WebDriverException e1) {
			e1.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public boolean alertAccept(WebDriver webdriver){
		boolean bReturn = false;

		try {
			driver.switchTo().alert().accept();
			bReturn = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;

	}

	public String getTextAndAcceptAlert(WebDriver webdriver){
		String sText = "";
		try{
			sText = driver.switchTo().alert().getText();
			alertAccept(webdriver);
		} catch(Exception e){
			e.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}

		return sText;
	}

	public boolean switchToLastWindow(WebDriver webdriver) {
		boolean bReturn = false;
		try {
			Set<String> wHandles = driver.getWindowHandles();
			for (String wHandle : wHandles) {
				driver.switchTo().window(wHandle);				
			}
			bReturn = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public boolean switchToParentWindow(WebDriver webdriver) {
		boolean bReturn = false;
		try{
			Set<String> wHandles = driver.getWindowHandles();
			for (String wHandle : wHandles) {
				driver.switchTo().window(wHandle);
				break;
			}
			bReturn = true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}

		return bReturn;

	}

	public boolean waitUseThread(int time, WebDriver webdriver) {
		boolean bReturn = false;
		try {
			Thread.sleep(time);
			bReturn = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public void verifyTextById(String id, String text, WebDriver webdriver) throws Exception {

		try {
			String getText = webdriver.findElement(By.id(id)).getText();
			if(getText.equals(text)){
				LOGGER.log(Level.INFO, "The Text: "+text+ "matched with the Element");

			}
		} catch (NoSuchElementException e) {

			LOGGER.log(Level.INFO, "The Text: "+text+ "counld not matched");
			throw new Exception("TestCase Stop");

		}
	}

	public String verifyAttributeTextById(String id, String value, String txt, WebDriver webdriver) throws Exception {
		String getText = "";
		try {
			getText = webdriver.findElement(By.id(id)).getAttribute(value);
			if(getText.equals(txt)){
				LOGGER.log(Level.INFO, "The Text: "+value+ " matched with the Element");

			}
		} catch (NoSuchElementException e) {

			LOGGER.log(Level.INFO, "The Text: "+value+ " counld not matched");
			throw new Exception("TestCase Stop");

		}
		return getText;
	}

	public boolean selectByIndexById(String id, int value, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new Select(webdriver.findElement(By.id(id))).selectByIndex(value);;
			LOGGER.log(Level.INFO, "The element with id: "+id+" is selected with value :"+value);

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The value: "+value+" could not be selected.");
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public boolean selectByValueById(String id, String value, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new Select(webdriver.findElement(By.id(id))).selectByValue(value);
			LOGGER.log(Level.INFO, "The element with id: "+id+" is selected with value :"+value);

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The value: "+value+" could not be selected.");
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	/**
	 * This method will select the drop down value using id as locator
	 * @param id The id (locator) of the drop down element
	 * @param value The value to be selected (visibletext) from the dropdown 
	 * @throws Exception 
	 * 
	 */
	public boolean selectVisibileTextById(String id, String value, WebDriver webdriver) throws Exception {
		boolean bReturn = false;
		try{
			new Select(webdriver.findElement(By.id(id))).selectByVisibleText(value);
			LOGGER.log(Level.INFO, "The element with id: "+id+" is selected with value :"+value);

			bReturn = true;

		} catch (Exception e) {
			LOGGER.log(Level.INFO, "The value: "+value+" could not be selected.");
			throw new Exception("TestCase Stop");
		}
		finally {
			takeSnap(webdriver);
		}
		return bReturn;
	}

	public void takeSnap(WebDriver webdriver) {
		
		TakesScreenshot scrShot =((TakesScreenshot)webdriver);
		File srcFile1 = scrShot.getScreenshotAs(OutputType.FILE);
		File destFile1 = new File("./target/snaps/snap"+getRandomNumAsString()+".jpeg");

		try {
			FileUtils.copyFile(srcFile1, destFile1);
		} catch (IOException e) {

			LOGGER.log(Level.INFO, "There was IO Exception while taking the SnapShot");
			e.printStackTrace();
		}
	}

//	Driver will wait for  page Loading image disappearing 
	int count = 0;
	public void customType(String Locator, String Text) {
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.MILLISECONDS);
		try {
			int fieldLength = Text.length();
			String actualText;
			if (driver.findElement(By.name(Locator)).isDisplayed() && fieldLength != 0) {
				do {
					driver.findElement(By.name(Locator)).clear();
					driver.findElement(By.name(Locator)).sendKeys(Text);
					actualText = driver.findElement(By.name(Locator)).getAttribute("value");
					count = count + 1;
				} while (!Text.equals(actualText) && count != 10);
			}
		} catch (Exception e) {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			e.printStackTrace();
		}

		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	}
	
	public static String getFileSeparator() {
	    return System.getProperty("file.separator");
	  }
	  
	  public static Date getCurrentTime() {
	    Calendar calendar = Calendar.getInstance();
	    return calendar.getTime();
	  }
	  
	  public static String getCurrentFormattedTime(String dateFormatString) {
	    DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
	    Calendar calendar = Calendar.getInstance();
	    return dateFormat.format(calendar.getTime());
	  }
	  
	  public static String getFormattedTime(Date time, String dateFormatString) {
	    DateFormat dateFormat = new SimpleDateFormat(dateFormatString);
	    return dateFormat.format(time);
	  }
	  
	  public static String getTimeDifference(Date startTime, Date endTime) {
	    long timeDifference = endTime.getTime() - startTime.getTime();
	    timeDifference /= 1000L;
	    String timeDifferenceDetailed = String.valueOf(Long.toString(timeDifference / 60L)) + " minute(s), " + 
	      Long.toString(timeDifference % 60L) + " seconds";
	    return timeDifferenceDetailed;
	  }
	  
	  public void customSleepOne() {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		public void customSleep() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		public String getElementXPath(WebDriver driver, WebElement element) {
			String javaScript = "function getElementXPath(elt){" + "var path = \"\";" + "for (; elt && elt.nodeType == 1; elt = elt.parentNode){" + "idx = getElementIdx(elt);" + "xname = elt.tagName;" + "if (idx > 1){" + "xname += \"[\" + idx + \"]\";" + "}" + "path = \"/\" + xname + path;" + "}" + "return path;" + "}" + "function getElementIdx(elt){" + "var count = 1;" + "for (var sib = elt.previousSibling; sib ; sib = sib.previousSibling){" + "if(sib.nodeType == 1 && sib.tagName == elt.tagName){" + "count++;" + "}" + "}" + "return count;" + "}" + "return getElementXPath(arguments[0]).toLowerCase();";

			return (String) ((JavascriptExecutor) driver).executeScript(javaScript, element);
		}
		
		public void customWait(String Type, String Element) {
			//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			if (Type.equals("name")) {
				do {
					try {
						Thread.sleep(waittime);
						timecount = timecount + waittime;
						LOGGER.log(Level.INFO, "current waitime for " + Element + " is " + timecount);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} while (!driver.findElement(By.name(Element)).isDisplayed() && timecount != maxtimecount);
				timecount = 0;
			}
			if (Type.equals("id")) {
				do {
					try {
						Thread.sleep(waittime);
						timecount = timecount + waittime;
						LOGGER.log(Level.INFO, "current waitime for " + Element + " is " + timecount);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} while (!driver.findElement(By.id(Element)).isDisplayed() && timecount != maxtimecount);
				timecount = 0;
			}
			if (Type.equals("xpath")) {
				do {
					try {
						Thread.sleep(waittime);
						timecount = timecount + waittime;
						LOGGER.log(Level.INFO, "current waitime for " + Element + " is " + timecount);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} while (!driver.findElement(By.xpath(Element)).isDisplayed() && timecount != maxtimecount);
				timecount = 0;
			}
			if (Type.equals("text")) {
				String pageText = null;
				do {
					try {
						Thread.sleep(waittime);
						timecount = timecount + waittime;
						pageText = driver.findElement(By.tagName("body")).getText();
						LOGGER.log(Level.INFO, "current waitime for " + Element + " is " + timecount);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} while (!pageText.contains(Element) && timecount != maxtimecount);
				timecount = 0;
			}
		}

		public void dynamicWait(long waitTime, String Type, String Element) {
			if (Type.equals("name")) {
				WebDriverWait wait = new WebDriverWait(driver, waitTime);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(Element)));
			} else if (Type.equals("id")) {
				WebDriverWait wait = new WebDriverWait(driver, waitTime);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(Element)));
			} else if (Type.equals("xpath")) {
				WebDriverWait wait = new WebDriverWait(driver, waitTime);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Element)));
			} else if (Type.equals("text")) {
				WebDriverWait wait = new WebDriverWait(driver, waitTime);
				wait.until(ExpectedConditions.textToBePresentInElementValue(By.tagName("td"), Element));
			} else if (Type.equals("div")) {
				WebDriverWait wait = new WebDriverWait(driver, waitTime);
				wait.until(ExpectedConditions.textToBePresentInElementValue(By.tagName("div"), Element));
			}
		}

		public void customWaitForElement(String Type, String Element) {
			boolean isElementDisplayed = false;
			int counter = 0;
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			if (Type.equals("name")) {
				do {
					try {
						customSleep();
						driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
						if (driver.findElement(By.name(Element)).isDisplayed())
							isElementDisplayed = true;
					} catch (Exception e) {
						isElementDisplayed = false;
						counter = counter + 1;
					}
				} while (!isElementDisplayed && counter != maxtimecounter);
				counter = 0;
				isElementDisplayed = false;
			} else if (Type.equals("id")) {
				do {
					try {
						customSleep();
						driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
						if (driver.findElement(By.id(Element)).isDisplayed())
							isElementDisplayed = true;
					} catch (Exception e) {
						isElementDisplayed = false;
						counter = counter + 1;
					}
				} while (!isElementDisplayed && counter != maxtimecounter);
				counter = 0;
				isElementDisplayed = false;
			} else if (Type.equals("xpath")) {
				do {
					try {
						customSleep();
						driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
						if (driver.findElement(By.xpath(Element)).isDisplayed())
							isElementDisplayed = true;
					} catch (Exception e) {
						isElementDisplayed = false;
						counter = counter + 1;
					}
				} while (!isElementDisplayed && counter != maxtimecounter);
				counter = 0;
				isElementDisplayed = false;
			}
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		}
		
		public void selectCheckBoxValue(String element, String value) {
			try {
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
				if (driver.findElement(By.xpath(element)).isDisplayed() && !value.isEmpty()) {
					if (value.equals("Yes"))
						driver.findElement(By.xpath(element)).click();
				}
			} catch (Exception e) {
				driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			}

		}
		
		public void getPageTitle(String title)
		{ 


			if(driver.getTitle().equals(title))
				LOGGER.log(Level.INFO, "Browser Window Title :"+driver.getTitle());

				//report.updateTestLog("RBTLogin", "Browser Window Title :"+driver.getTitle(), Status.PASS);
			else {
				LOGGER.log(Level.INFO, "Browser Window Title is not unique");
			}

				//report.updateTestLog("RBTLogin", "Browser Window Title is not unique", Status.FAIL);}


		}

		public void clickElement(String Element, String Text, String ElementName) {
			try {
				String pageText;
				int count = 0;
				do {
					driver.findElement(By.xpath(Element)).click();
					customSleep();
					customSleep();
					count = count + 1;
					pageText = driver.findElement(By.tagName("body")).getText();
				} while (!pageText.toLowerCase().contains(Text.trim().toLowerCase()) && count != 40);
				//report.updateTestLog("GEO Login", ElementName + " is clicked", Status.PASS);
			} catch (Exception e) {
				//frameworkParameters.setStopExecution(false);
				throw new FrameworkException("Click", "Error in entering clicking on" + ElementName + "in the page");
			}
		}

		public boolean isDateBetween(String Stdate, String EndDt, String TestDt) throws ParseException {
			SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdfDate1 = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdfDate2 = new SimpleDateFormat("dd/MM/yyyy");
			Date DtStrt = sdfDate.parse(Stdate);
			Date DtEnd = sdfDate1.parse(EndDt);
			Date DtTest = sdfDate2.parse(TestDt);
			if ((DtStrt.compareTo(DtTest) <= 0) && (DtTest.compareTo(DtEnd) <= 0))
				return true;
			else
				return false;
		}

		public boolean isDateBetweenParsing(String Stdate, String EndDt, String TestDt) throws ParseException {
			SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MMM/yyyy");
			SimpleDateFormat sdfDate1 = new SimpleDateFormat("dd/MM/yyyy");
			Date DtStrt = sdfDate.parse(Stdate);
			Date DtEnd = sdfDate.parse(EndDt);
			Date DtTest = sdfDate1.parse(TestDt);
			if ((DtStrt.compareTo(DtTest) <= 0) && (DtTest.compareTo(DtEnd) <= 0))
				return true;
			else
				return false;
		}

		public String subtractDate(String timeZone, int minusDate) {
			Date date = new Date();
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			TimeZone T1 = TimeZone.getTimeZone(timeZone);
			dateFormat.setTimeZone(T1);
			Date dateBefore = new Date(date.getTime() - minusDate * 24 * 3600 * 1000);
			String previousDate = dateFormat.format(dateBefore);
			return previousDate;
		}
		
		public void highlightElement(WebElement element, WebDriver driver) {
			JavascriptExecutor js = ((JavascriptExecutor) driver);
			String bgcolor = element.getCssValue("backgroundColor");
			changeColor(element, js);
			// changeColor(bgcolor, element, js);
		}

		public void changeColor(WebElement element, JavascriptExecutor js) {
			js.executeScript("arguments[0].style.border='2px solid red'", element);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}

		public void waitForElement(By by) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.presenceOfElementLocated(by));
			} catch (Exception e) {
			}
		}

		public void waitForElementToBeClickable(By locator) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.elementToBeClickable(locator));
			} catch (Exception e) {
			}
		}

		public void scrollUp() {
			try {
				EventFiringWebDriver driver1 = new EventFiringWebDriver(driver);
				driver1.executeAsyncScript("scroll(0,-350)");
			} catch (Exception e) {
			}
		}
		
		public void scrollDown() {
			try {
				EventFiringWebDriver driver1 = new EventFiringWebDriver(driver);
				driver1.executeAsyncScript("scroll(0,2000)");
			} catch (Exception e) {
			}
		}
		
		//return boolean value for element is existed in web page or not
		public boolean isThere(String locatorType, String expression){
			boolean displayed = false;
			try {
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
				switch (locatorType){
				case "xpath":
					displayed = driver.findElements(By.xpath(expression)).size() != 0;
					break;
				case "name":
					displayed = driver.findElements(By.name(expression)).size() != 0;
					break;
				default:
					break;
				}
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//report.updateTestLog("VerifyElement", "Error in verifying the element", Status.FAIL);
			}
			return displayed;
		}
		//	Driver will wait for  page Loading image disappearing 
		public void loadingImgWait(){
			try {
				do{
					Thread.sleep(1000);
					LOGGER.log(Level.INFO, "Page is being loading...");
				}while(isThere("xpath","//img[contains(@src,'wait.gif')]"));
			} catch (InterruptedException e) {
				e.printStackTrace();
				throw new FrameworkException("Frame Work", "Error in Loading image disapearing");
			}	}

		public void loadingImgWaitResUI(){
			try {
				WebDriverWait wait=new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='gpfi dimmer inverted active ng-scope']")));
			}
			catch (Exception e){
				throw new FrameworkException("Frame Work", "Error in Loading image disapearing");
			}
		}
		
//		Unique number Creation
		public String getRandomNumAsString(){
			String randomNumber= "";
			try{
				DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
				Date date = new Date();
				String dt=dateFormat.format(date).toString();
				randomNumber=dt.replace(":", "");
				LOGGER.log(Level.INFO, "Generated random number is:"+randomNumber);
			}catch(Exception e){
				LOGGER.log(Level.INFO, "Error while generating random number!");
			}
			return randomNumber;
		}
		
//		Element display verification 
		public boolean isDisplay(String locatorType,String locator){
			boolean displayed = false;
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
			switch (locatorType){
			case "xpath":
				try{
					driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
					displayed = driver.findElement(By.xpath(locator)).isDisplayed();
				}catch (Exception e) {
					driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				}
				break;
			case "name":
				try{
					driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
					displayed = driver.findElement(By.name(locator)).isDisplayed();
				}catch (Exception e) {
					driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
				}
			default:
				break;
			}
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			return displayed;
		}
		//	upload file when input type='text
		public boolean uploadFile(String filePath){
			boolean isUploaded = false;
			try{
				boolean WindowsAppFlag = true;
				LOGGER.log(Level.INFO, "Info# Uploading File path :"+filePath);
				File file = new File(filePath);
				if(file.exists()){
					StringSelection stringSelection = new StringSelection(file.getAbsolutePath());
					Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
					Robot robot = new Robot();
					Thread.sleep(3000);
					robot.delay(500);
					robot.keyPress(KeyEvent.VK_CONTROL);
					robot.keyPress(KeyEvent.VK_V);
					robot.keyRelease(KeyEvent.VK_V);
					robot.keyRelease(KeyEvent.VK_CONTROL);
					robot.delay(500);
					robot.keyPress(KeyEvent.VK_ENTER);
					robot.delay(50);
					robot.keyRelease(KeyEvent.VK_ENTER);
					isUploaded= true;
					//report.updateTestLog("", "File upload window is opened and successfully file is uploaded", Status.PASS);
					WindowsAppFlag = false;
				}else{
					LOGGER.log(Level.INFO, "*********************************");
					LOGGER.log(Level.INFO, "Error# File Not Found given path '"+filePath+"'");
					isUploaded = false;
				}
			}catch(Exception e){
				isUploaded=false;
				LOGGER.log(Level.INFO, "Error# while uploading file...!");
			}
			return isUploaded;
		}

		//	save downloading file
		public void saveFile(){
			try{
				Robot robot = new Robot();
				Thread.sleep(3000);
				// selecting save file radio button in popup
				robot.keyPress(KeyEvent.VK_ALT);
				robot.keyPress(KeyEvent.VK_S);
				robot.delay(10);
				robot.keyRelease(KeyEvent.VK_S);
				robot.keyRelease(KeyEvent.VK_ALT);
				robot.delay(200);
				// pressing ok button in popup
				robot.keyPress(KeyEvent.VK_ENTER);
				robot.delay(10);
				robot.keyRelease(KeyEvent.VK_ENTER);
			}catch(Exception e){
				LOGGER.log(Level.INFO, "Error# while downloading file...!");
			}
		}
		//	verifying file download
		public boolean isFileDownloaded(String downloadPath, String fileName) {
			boolean flag = false;
			File dir = new File(downloadPath);
			File[] dir_contents = dir.listFiles();
			for (int i = 0; i < dir_contents.length; i++) {
				if (dir_contents[i].getName().equals(fileName))
					return flag=true;
			}
			return flag;
		}

		//	Download Path getting from Properties file
		public String getDownloadPath(){
			String downloadPath = "C:\\Users\\";
			try {
				String username = System.getProperty("user.name");
				downloadPath = downloadPath+username+"\\Downloads";
				LOGGER.log(Level.INFO, "Download Path # "+downloadPath);
				if(!new File(downloadPath).isDirectory()){
					throw new RuntimeException();
				}
			} catch (RuntimeException re){
				LOGGER.log(Level.INFO, "Error# '"+downloadPath+"' is not found!");
				LOGGER.log(Level.INFO, "Info# Plz change to valid directory.");
			}
			return downloadPath;
		}
		
		public WebElement getWebElement(String locatorType,String locator)
		{
			WebElement element = null;
			try{
				JavascriptExecutor js = (JavascriptExecutor)driver;
				if(locatorType.equalsIgnoreCase("xpath")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
					js.executeScript("arguments[0].style.border='2px dotted blue'", element);
					return element;
				}
				else if(locatorType.equalsIgnoreCase("id")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.id(locator)));
					js.executeScript("arguments[0].style.border='4px solid blue'", element);
					return element;
				}
				else if(locatorType.equalsIgnoreCase("name")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.name(locator)));
					js.executeScript("arguments[0].style.border='4px solid blue'", element);
					return element;
				}
				else if(locatorType.equalsIgnoreCase("cssselector")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(locator)));
					js.executeScript("arguments[0].style.border='4px solid blue'", element);
					return element;
				}
				else if(locatorType.equalsIgnoreCase("class")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.className(locator)));
					js.executeScript("arguments[0].style.border='4px solid blue'", element);
					return element;
				}
				else if(locatorType.equalsIgnoreCase("linktext")){
					WebDriverWait w = new WebDriverWait(driver,90);
					element = w.until(ExpectedConditions.presenceOfElementLocated(By.linkText(locator)));
					js.executeScript("arguments[0].style.border='4px solid blue'", element);
					return element;
				}
			} catch(Exception e)
			{
				//report.updateTestLog("GEO-Getting WebElement", "Error occurred while getting webelement", Status.FAIL);
				return element;
			}
			return element;
		}
		
		public int countOfWebelements(String xpathValue)
		{
			List<WebElement> list = driver.findElements(By.xpath(xpathValue));
			return list.size();
		}
		
		public String getTextValue(String locatorType,String locator)
		{
			WebElement element = getWebElement(locatorType, locator);
			String str= element.getText();
			return str;
		}

		public String getAttributeValue(String locatorType,String locator)
		{
			WebElement element = getWebElement(locatorType, locator);
			String str= element.getAttribute("value");
			return str;
		}

		public int getWebElementSize(String locator)
		{
			int str= driver.findElements(By.xpath(locator)).size();

			return str;
		}
		public String getTextValue(WebElement element)
		{
			String str=null;
			try {
				str= element.getText();

			} catch (Exception e) {
				//report.updateTestLog("getTextValue", "Not able to get text from the element", Status.FAIL);
			}
			return str;
		}
		
		public void scrollToTarget(String xpath) {

			try {
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath(xpath)));
				customSleep();
			} catch (Exception e) {
				throw new FrameworkException("GEO - scrollToTarget", "Error occurred while scrolling to the target element");
			}
		}
		
		public void scrollToTarget(String LocatorType, String Locator) {

			try {
				JavascriptExecutor js = (JavascriptExecutor)driver;
				if(LocatorType.equalsIgnoreCase("xpath")){
					js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath(Locator)));
				}else if(LocatorType.equalsIgnoreCase("name")){
					js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.name(Locator)));
				}else if(LocatorType.equalsIgnoreCase("id")){
					js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.id(Locator)));
				}else if(LocatorType.equalsIgnoreCase("cssSelector")){
					js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.cssSelector(Locator)));
				}
				customSleep();
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.log(Level.INFO, " ");
			}
		}
		
		public void scrollToTarget(WebElement Locator) {

			try {
				JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("arguments[0].scrollIntoView(true);", Locator);
				customSleep();
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.log(Level.INFO, " ");
			}
		}
		
		public void switchToFrame(String frameName) {
			try {
				driver.switchTo().frame(frameName);
			} catch (Exception e) {
				throw new FrameworkException("SwitchFrame", "Error occurred while switching to the frame");
			}
		}
		
		public void switchToNewWindow() {
			try {
				for (String newTab : driver.getWindowHandles()) {
					driver.switchTo().window(newTab);
				}   
			} catch (Exception e) {
				throw new FrameworkException("SwitchWindow", "Error occurred while switching to new window/tab");
			}
		}
		
		public boolean selectValueFromOptions(String locatorType, String locator, String selection, String value)
		{
			WebElement element = getWebElement(locatorType, locator);
			boolean isOptionSelected = false;
			try {
				if(element == null)
				{
					//report.updateTestLog("GEO - selectValueFromOptions", "WebElement not found/available", Status.FAIL);
					return false;
				}
				element.click();
				if(selection.equalsIgnoreCase("ByValue")) {
					Select s = new Select(element);
					s.selectByValue(value);
					isOptionSelected = true;
					return isOptionSelected;
				}else if(selection.equalsIgnoreCase("ByVisibleText")) {
					Select s = new Select(element);
					s.selectByVisibleText(value);
					isOptionSelected = true;
					return isOptionSelected;
				}
			} catch (Exception e) {
				throw new FrameworkException("GEO - selectValueFromOptions", "Error in selecting value from dropdown menu");
			}
			return isOptionSelected;
		}
		
		public void waitForElementPresence(String locatorType,String locator) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				if(locatorType.equalsIgnoreCase("xpath"))
				{
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
				}else if(locatorType.equalsIgnoreCase("id")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.id(locator)));
				}else if(locatorType.equalsIgnoreCase("name")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.name(locator)));
				}else if(locatorType.equalsIgnoreCase("cssSelector")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(locator)));
				}else if(locatorType.equalsIgnoreCase("class")) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.className(locator)));
				}
			}catch (Exception e) {
				throw new FrameworkException("WaitForElementPresence", "Error occurred while waiting for the Element presence");
			}
		}
		
		public void waitForElementPresence(By locator) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.presenceOfElementLocated(locator));			
			}catch (Exception e) {
				throw new FrameworkException("WaitForElementPresence", "Error occurred while waiting for the Element presence");
			}
		}
		
		public boolean compareTwoStrings(String actual,String expected,String name)
		{
			boolean flag=false;
			try {
				if(actual.equals(expected))
				{
					//report.updateTestLog("CompareStrings", "The Actual "+name+": \""+actual+ "\" matches with the expected value: \""+expected+"\".", Status.PASS);
					flag=true;
				}
				else
				{
					//report.updateTestLog("CompareStrings", "The Actual "+name+": \""+actual+ "\" doesnot match with the expected value: \""+expected+"\".", Status.FAIL);
					flag=false;
				}
			} catch (Exception e) {
				//report.updateTestLog("CompareStrings", "Not able toCompare the strings", Status.FAIL);
				e.printStackTrace();

			}
			return flag;

		}
		public boolean compareTwoStringsPartially(String one,String two,String name)
		{
			boolean flag=false;
			try {
				if(one.contains(two))
				{
					//report.updateTestLog("CompareStrings", "The "+name+" "+one+" and  "+two+" matches partially", Status.DONE);
					flag=true;
				}
				else
				{
					//report.updateTestLog("CompareStrings", "The "+name+" "+one+" and  "+two+" does not match partially", Status.FAIL);
					flag=false;
				}
			} catch (Exception e) {
				//report.updateTestLog("CompareStrings", "Not able toCompare the strings", Status.FAIL);
				e.printStackTrace();

			}
			return flag;

		}
		
		public boolean compareTwoStringsPartiallyNoreport(String first,String Second)
		{
			boolean flag=false;
			try {
				if(first.contains(Second))
				{

					flag=true;
				}
				else
				{

					flag=false;
				}
			} catch (Exception e) {
				//report.updateTestLog("CompareStrings", "Not able toCompare the strings", Status.FAIL);
				e.printStackTrace();

			}
			return flag;

		}
		
		public String selectDataFromTable(WebElement table,String coloumn,String data)
		{
			String selectedrow=null;
			try{

				Boolean result=false;
				int coloumnNumber=Integer.parseInt(coloumn);
				WebDriverWait wait=new WebDriverWait(driver,60);
				wait.until(ExpectedConditions.visibilityOfAllElements(table.findElements(By.tagName("tr"))));
				List<WebElement>rows=table.findElements(By.tagName("tr"));
				for(WebElement eachrow:rows)
				{
					//wait.until(ExpectedConditions.visibilityOfAllElements(eachrow.findElements(By.tagName("td"))));
					List<WebElement>coloumns=eachrow.findElements(By.tagName("th"));
					String actualData=coloumns.get(coloumnNumber).getText();
					if(data.equals(actualData))
					{
						selectedrow=Integer.toString(rows.indexOf(eachrow));
						result=true;
						break;

					}

				}
				if(result) 
				{
					//report.updateTestLog("SelectDataFromTable", "The data "+data+" is available in the table" ,Status.PASS);

				}


				return selectedrow;
			} catch (NumberFormatException e)
			{
				//report.updateTestLog("SelectDataFromTable", "Not able to validate the data in the table" ,Status.FAIL);
				return selectedrow;
			}
		}


		public void mouseover(String locator, String value,String msg)
		{
			try {
				WebElement element=getWebElement(locator,value);
				Actions mouse=new Actions(driver);
				mouse.moveToElement(element).build().perform();
				//report.updateTestLog("ClickAndHold", "Clicked on the element"+msg, Status.PASS);
			} catch (Exception e) {
				//report.updateTestLog("ClickAndHold", " Not able to click on the element"+msg, Status.FAIL);
			}
		}

		@SuppressWarnings("finally")
		public boolean isDisplayed(String locator,String locatorvalue,String name)
		{
			boolean flag=true;
			try {

				WebElement webElement = getWebElement(locator, locatorvalue);
				if(webElement.isDisplayed())
				{
					flag= true;

				}
				else 
				{
					flag= false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			finally
			{
				return flag;
			}

		}

		//Method to clear value from a text box
		public boolean clearValue(String locatorType,String locator,String msg)
		{
			WebElement element = getWebElement(locatorType, locator);
			try{
				if(element == null)
				{
					return false;
				}
				element.clear();
				customSleep();
				
			}catch(Exception e)
			{
				throw new FrameworkException("GEO-Enter Value", "Error occurred while entering text");
			}
			return true;
		}

		public void switchWindows(int index)
		{	try {
			//	String ind=dataTable.getData("Seller_Portal", "WindowIndex");
			//		int index=Integer.parseInt(ind);
			Set<String> windows=driver.getWindowHandles();
			List<String> windowList=new ArrayList<>();
			windowList.addAll(windows);
			driver.switchTo().window(windowList.get(index));
			//report.updateTestLog("SwitchWindows", "Successfully switched to Window", Status.PASS);
		} catch (NumberFormatException e) {
			//report.updateTestLog("SwitchWindows", "Not able to switch to Window", Status.FAIL);
		}
		}
		
		public void openNewTab() throws AWTException {
			Robot r;
			//	driver.manage().deleteAllCookies();
			//	Actions key=new Actions(driver);
			//	key.sendKeys(Keys.CONTROL+"t");
			r = new Robot();

			r.keyPress(KeyEvent.VK_CONTROL);

			r.keyPress(KeyEvent.VK_T);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_T);
			LOGGER.log(Level.INFO, "Opened New tab in browser");
			//report.updateTestLog("GPFI", "Opened new tab in browser successfully", Status.PASS);
			Set<String> childWindow = driver.getWindowHandles();
			for(String newWindow:childWindow){
				driver.switchTo().window(newWindow);
				LOGGER.log(Level.INFO, "Driver focus is switched to New window/tab");
			}
			//	for(Cookie ck:driver.manage().getCookies())
			//	{
			//		driver.manage().deleteCookie(ck);
			//	}
			customSleep();
		}
		
		public void customType(String locatorType, String Locator, String Text, int waitTime) {
			//driver.manage().timeouts().implicitlyWait(300, TimeUnit.MILLISECONDS);
			if (locatorType.contains("name")) {
				try {
					if (driver.findElement(By.name(Locator)).isDisplayed()) {
						driver.findElement(By.name(Locator)).clear();
						for (int i = 0; i < Text.length(); i++) {
							try {
								driver.findElement(By.name(Locator)).sendKeys(Character.toString(Text.charAt(i)));
								try {
									Thread.sleep(waitTime);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							} catch (Exception e) {
								LOGGER.log(Level.INFO, "Continue Typing");
							}
						}
					}
				} catch (Exception e) {
					//frameworkParameters.setStopExecution(false);
					throw new FrameworkException("", "Error in entering data in " + Locator);
				}
			} else {
				try {
					if (driver.findElement(By.xpath(Locator)).isDisplayed()) {
						driver.findElement(By.xpath(Locator)).clear();
						for (int i = 0; i < Text.length(); i++) {
							try {

								driver.findElement(By.xpath(Locator)).sendKeys(Character.toString(Text.charAt(i)));
								try {
									Thread.sleep(waitTime);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							} catch (Exception e) {
								LOGGER.log(Level.INFO, "Continue Typing");
							}
						}
					}
				} catch (Exception e) {
					//frameworkParameters.setStopExecution(false);
					throw new FrameworkException("", "Error in entering data");
				}
			}
			customSleepOne();
			driver.manage().timeouts().implicitlyWait(180, TimeUnit.SECONDS);
		}
		
		public boolean enterValue(String locatorType,String locator, String text)
		{
			WebElement element = getWebElement(locatorType, locator);
			try{
				if(element == null || text.isEmpty())
				{
					//report.updateTestLog("GEO-Enter Value", "WebElement not found/available", Status.FAIL);
					return false;
				}
				element.clear();
				element.sendKeys(text);
				//report.updateTestLog("GEO-Enter Value", "Entered text:"+text, Status.DONE);
			}catch(Exception e)
			{
				throw new FrameworkException("Enter Value", "Error occurred while entering text");
			}
			return true;
		}
		
		//Method Overloading with Additional parameters
		public boolean enterValue(String locatorType,String locator, String text,String msg)
		{
			WebElement element = getWebElement(locatorType, locator);
			try{
				if(element == null)
				{
					//report.updateTestLog("GEO-Enter Value", "WebElement not found/available for "+msg, Status.FAIL);
					LOGGER.log(Level.INFO, "WebElement not found/available for "+msg);
					return false;
				}
				element.clear();
				//customSleepOne();
				element.sendKeys(text);
				////report.updateTestLog("GEO-Enter Value", msg+" is entered as "+text, Status.DONE);
			}catch(Exception e)
			{
				throw new FrameworkException("Enter Value", "Error occurred while entering "+msg);
			}
			return true;
		}
		
		public boolean clickWebElement(String locType, String locator,String msg){
			WebElement element = getWebElement(locType, locator);
			try{
				if(element == null){
					//report.updateTestLog("GEO-Click WebElement", "WebElement not found/available for "+msg, Status.FAIL);
					return false;
				}
				element.click();
				////report.updateTestLog("GEO-Click WebElement", "Clicked on "+ msg, Status.DONE);
			}catch(Exception e){
				throw new FrameworkException("Click WebElement", "Error occurred while clicking on "+msg);
			}
			return true;
		}
		
		public void clickAndWait(String eleLoc,String eleLocValue,String eleName,String waitEleLoc,String waitEleLocValue)
		{
			try {
				clickWebElement(eleLoc, eleLocValue,eleName);
				waitForElementPresence(waitEleLoc, waitEleLocValue);
			} catch (ElementNotInteractableException e) {
				e.printStackTrace();
				throw new FrameworkException("ClickElement", "Element Not found to click: "+eleName);
			}
			catch (StaleElementReferenceException e) {
				e.printStackTrace();
				throw new FrameworkException("ClickElement", "Not able to click "+eleName);
			}
			catch(Exception e) {
				e.printStackTrace();
				throw new FrameworkException("ClickElement", "Not able to click "+eleName);

			}
		}
		
		public void isFileAvailable(String fpathandNamewithext,String msg)
		{
			try {
				File file = new File(fpathandNamewithext); 
				if(file.exists())
				{
					//report.updateTestLog("isFileAvailable", msg+" is available", Status.PASS);
				}
				else
				{
					//report.updateTestLog("isFileAvailable", msg+" is not available", Status.FAIL);
				}
			} catch (Exception e) {

				e.printStackTrace();
				throw new FrameworkException("isFileAvailable", "Not able to Validate File presence");
			}
		}
		
		public void switchToCurrentWindow() {
			try {
				String currentWind=driver.getWindowHandle();
				Set<String> testWind=driver.getWindowHandles();

				for (String newTab : testWind) {
					if(!currentWind.equals(newTab))
						driver.switchTo().window(newTab);
				}   
			} catch (Exception e) {
				throw new FrameworkException("SwitchToNewWindow", "Error occurred while switching to new window/tab");
			}
		}

		public int setRandomNumber(int start,int end)
		{
			double random = Math.random();
			return (int) (start+random*(end-start));
		}

		public int setRandomNumber(int end)
		{
			double random = Math.random();
			return (int) (random*end);
		}
		
		public void validatePresenceOfText(String Data) {
			String relativeXpath = "//*[contains(text(),\"xxxx\")]";
			relativeXpath = relativeXpath.replace("xxxx", Data);
			WebElement element =driver.findElement(By.xpath(relativeXpath));
			if (element.isDisplayed()) {
				//report.updateTestLog("validatePresenceOfText", "\""+Data+"\" is found in page", Status.PASS);
			} else {
				//report.updateTestLog("validatePresenceOfText", "\""+Data+"\" is NOT found in page", Status.FAIL);
			}
		}
		
		public void waitForElementToBeInVisible(By by) {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 240);
				Boolean element = wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

}