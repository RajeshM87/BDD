package com.qa.util;

import helper.AllureLogger;
import helper.FrameworkConstants;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasSize;


public abstract class APIUtility {

	protected static Properties properties;
	public final static Logger LOGGER =
			Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	public static String readConfigurationFile(String key) {
		try{
			properties = new Properties();
			properties.load(new FileInputStream(FrameworkConstants.CONFIG_FILE_PATH));
			//LOGGER.log(Level.INFO,"API configuration file is loaded successfully!!");

		} catch (Exception e){
			LOGGER.log(Level.INFO,"Cannot find key: "+key+" in Config file due to exception : "+e);
		}
		return properties.getProperty(key).trim();
	}

	public static JSONObject returnDefaultPayLoadObject(String filePath) {
		// To get the JSON request from external file
		JSONParser parser = new JSONParser();
		Object obj = null;
		try {
			obj = parser.parse(new FileReader(filePath));
		} catch (Exception e) {
			AllureLogger.logToAllure("Error in JSON object parsing with exception : "+e);
			LOGGER.log(Level.INFO, "Error in JSON object parsing with exception : "+e);

		}
		JSONObject jsonObject = (JSONObject) obj;
		return jsonObject;
	}

	public JSONObject loadRequestWithAuthData(JSONObject jsonObject, String username, String password) {

		jsonObject.put("username", username);
		jsonObject.put("password", password);
		LOGGER.log(Level.INFO,"Username: "+ username);
		LOGGER.log(Level.INFO,"Password: "+ password);

		return jsonObject;

	}

	/*******************************************************
	 * Print the response JSON
	 ******************************************************/

	public void logResponseAsString(Response response) {
		AllureLogger.logToAllure(response.asString());
		LOGGER.log(Level.INFO, "Response : "+ response.asString());

	}

	/*******************************************************
	 * Print the all output log along with the response json (headers, cookies etc)
	 ******************************************************/

	public void printOutputLog(Response response) {
		response.then().log().all();
		LOGGER.log(Level.INFO,"Response Output Log: "+ response.then().log().all());
	}

	/*******************************************************
	 * Asserting value of a single element to the given value
	 ******************************************************/

	public void assertingSingleElementValue(Response response, String jsonPathOfValue, String expectedValue) {
//		eg: response.then().assertThat().body("places[0].'place name'",equalTo(cityName));

		response.then().assertThat().body(jsonPathOfValue,equalTo(expectedValue));
		LOGGER.log(Level.INFO,"Assert Single Element: "+ response.then().assertThat().body(jsonPathOfValue,equalTo(expectedValue)));

	}

	/*******************************************************
	 * Asserting if the given value exist in the response
	 ******************************************************/

	public void assertingItemValueUsingHasItem(Response response, String jsonPathOfValue, String expectedValue) {

//		eg : response.then().assertThat().body("places.'place name'", hasItem(expectedValue));

		response.then().assertThat().body(jsonPathOfValue, hasItem(expectedValue));
		LOGGER.log(Level.INFO,"Assert Item Values : "+ response.then().assertThat().body(jsonPathOfValue, hasItem(expectedValue)));
	}


	/*******************************************************
	 * Asserting if the given value exist in the response using size
	 ******************************************************/

	public void assertingItemSizeUsingHasItem(Response response, String jsonPathOfValue, int size) {

//		eg : response.then().assertThat().body("places.'place name'", hasSize(size));
		response.then().assertThat().body(jsonPathOfValue, hasSize(size));
		LOGGER.log(Level.INFO,"Assert Item Size : "+ response.then().assertThat().body(jsonPathOfValue, hasSize(size)));
	}
}