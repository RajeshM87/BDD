package com.qa.util;

public class SQLLibrary {

	public static String getOrderStatus(String orderid)
	{
		return "select trsnid from mdm.t_orderinfo where OrderID ='" + orderid + "'";
	}
	
	public static String getPaymentStatus(String orderid)
	{
		return "select pymtnid from mdm.t_paymentinfo where OrderID ='" + orderid + "'";						
	}
}

