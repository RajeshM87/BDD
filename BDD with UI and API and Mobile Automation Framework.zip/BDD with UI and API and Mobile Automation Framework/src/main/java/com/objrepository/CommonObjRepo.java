package com.objrepository;

import org.openqa.selenium.By;

public class CommonObjRepo {
	
	private CommonObjRepo() {
		throw new IllegalStateException("Common");
	}

	public static final By userName = By.id("user-name");
	public static final By password = By.id("password");
	public static final By loginButton = By.name("login-button");
	public static final By menubutton = By.id("react-burger-menu-btn");
	public static final By logoutBtn = By.id("logout_sidebar_link");
	
	/*
	 * @FindBy(id ="user-name") public WebElement userName;
	 * 
	 * @FindBy(id ="password") public WebElement password;
	 * 
	 * @FindBy(name ="login-button") public WebElement loginButton;
	 * 
	 * @FindBy(id ="react-burger-menu-btn") public WebElement menubutton;
	 * 
	 * @FindBy(id ="logout_sidebar_link") public WebElement logoutBtn;
	 */	
	
	/*
	 * @ByAngularCssContainingText.FindBy(rootSelector = "button", cssSelector =
	 * "button.btn:nth-child(1)", searchText = "Save") public WebElement save;
	 * 
	 * @ByAngularModel.FindBy(rootSelector = "input", model = "state.senderName")
	 * public WebElement senderName;
	 * 
	 * @ByAngularButtonText.FindBy(rootSelector = "button", buttonText =
	 * "Get Quote") public static WebElement btn_getQuote;
	 */
	
}
