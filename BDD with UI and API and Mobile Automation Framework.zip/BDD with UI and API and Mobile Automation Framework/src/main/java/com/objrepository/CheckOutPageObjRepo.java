package com.objrepository;

import org.openqa.selenium.By;

public class CheckOutPageObjRepo {
	
	public static final By firstname = By.name("firstName");
	public static final By lastname = By.name("lastName");
	public static final By postalcode = By.name("postalCode");
	public static final By continuebtn = By.id("continue");
	public static final By finishbtn = By.id("finish");
	public static final By successmsg = By.xpath("//*[@id='checkout_complete_container']/h2");
	
	/*
	 * @FindBy(name = "firstName") public WebElement firstname;
	 * 
	 * @FindBy(name = "lastName") public WebElement lastname;
	 * 
	 * @FindBy(name = "postalCode") public WebElement postalcode;
	 * 
	 * @FindBy(id = "continue") public WebElement continuebtn;
	 * 
	 * @FindBy(id = "finish") public WebElement finishbtn;
	 * 
	 * @FindBy(xpath = "//*[@id='checkout_complete_container']/h2") public
	 * WebElement successmsg;
	 */
	
}
