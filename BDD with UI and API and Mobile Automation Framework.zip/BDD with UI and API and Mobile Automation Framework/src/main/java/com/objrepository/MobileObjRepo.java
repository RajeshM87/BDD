package com.objrepository;

import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;

public class MobileObjRepo {

 	public static final By txt_preference = By.xpath("//android.widget.TextView[@text='Preference']");
	public static final By txt_preference_xml = By.xpath("//android.widget.TextView[@text='1. Preferences from XML']");
	public static final By txt_preference_list = By.xpath("//android.widget.TextView[@text='List preference']");
	public static final MobileBy btn_text =(MobileBy) MobileBy.AccessibilityId("Text Button");
	public static final MobileBy inp_text_ios =(MobileBy) MobileBy.AccessibilityId("Text Input");
	public static final By inp_text_android = By.xpath("//android.widget.TextView[@text='Text Button']");
	public static final By firsttxt_preference_list = By.xpath("//android.widget.CheckedTextView[@text='Alpha Option 01']");

}
