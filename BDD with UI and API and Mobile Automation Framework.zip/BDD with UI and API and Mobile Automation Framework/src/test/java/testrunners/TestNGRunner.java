package testrunners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(

		features = {"src/test/resources/features"},
		glue = {"stepdefinitions", "ApplicationHooks"},		
		plugin = {"pretty",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm",
				"timeline:target/test-output-thread/","html:target/cucumber-html-reports", 
		        "json:target/cucumber-reports/cucumber.json", "junit:target/cucumber-reports/cucumber.xml", 
		        "rerun:target/failed_scenarios.txt"				
		},

		monochrome = true,
		tags = {"@Single"})

public class TestNGRunner extends AbstractTestNGCucumberTests {

}
	
