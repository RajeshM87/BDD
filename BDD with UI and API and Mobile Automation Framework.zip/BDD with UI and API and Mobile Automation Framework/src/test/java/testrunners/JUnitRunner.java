package testrunners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(

		features = {"src/test/resources/features"},
		glue = {"stepdefinitions", "ApplicationHooks"},
		plugin = { "pretty", "io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"html:target/cucumber-html-reports", "json:target/cucumber-reports/cucumber.json",
				"junit:target/cucumber-reports/cucumber.xml",
				"rerun:target/rerun.txt"
		},
		monochrome = true,
		tags = "@Fillo")


public class JUnitRunner {

}
