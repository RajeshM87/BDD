package stepdefinitions;

import com.apiClasses.*;
import com.pages.CheckOutPage;
import com.qa.factory.DriverFactory;
import helper.WaitHelper;
import io.cucumber.java.en.Then;

public class APIStepDefinitions {

	CreateBooking createbookingstepdef;
	GetBooking getbookingstepdef;
	PartialUpdateBooking partialupdatebookingstepdef;
	UpdateBooking updatebookingstepdef;
	DeleteBooking deletebookingstepdef;

	public APIStepDefinitions(){
		createbookingstepdef = new CreateBooking();
		getbookingstepdef = new GetBooking();
		partialupdatebookingstepdef = new PartialUpdateBooking();
		updatebookingstepdef = new UpdateBooking();
		deletebookingstepdef = new DeleteBooking();
	}
	
	@Then("^Create the Booking Order details using \"([^\"]*)\"$")
	public void create_the_booking_order_details(String TCID) throws Throwable {
		createbookingstepdef.createNewBooking(TCID);
	}

	@Then("^Get the Booking Order details using \"([^\"]*)\"$")
	public void get_the_booking_order_details(String TCID) throws Throwable {
		getbookingstepdef.getBookingIDs(TCID);
	}

	@Then("^Partial Update the Booking Order details using \"([^\"]*)\"$")
	public void partial_update_the_booking_order_details(String TCID) throws Throwable {
		partialupdatebookingstepdef.partialupdateBooking(TCID);
	}

	@Then("^Update the Booking Order details using \"([^\"]*)\"$")
	public void update_the_booking_order_details(String TCID) throws Throwable {
		updatebookingstepdef.updateBooking(TCID);
	}

	@Then("^Delete the Booking Order details$")
	public void delete_the_booking_order_details() throws Throwable {
		deletebookingstepdef.deleteBookingIDs();
	}
}