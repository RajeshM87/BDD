package stepdefinitions;

import com.pages.MobileActions;
import com.qa.factory.DriverFactory;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MobileStepDefinitions {

	MobileActions mobile;

	public MobileStepDefinitions(){
		mobile = new MobileActions((AppiumDriver<MobileElement>)DriverFactory.getAppiumDriver());
	}
	@Given("User clicks on text Preference")
	public void user_clicks_on_text_Preference() {
		mobile.clickOnTextPreference();
	}

	@When("User clicks on text Preference XML")
	public void user_clicks_on_text_Preference_XML() {
		mobile.clickOnTextPreferenceXML();
	}

	@Then("Options should be displayed")
	public void options_should_be_displayed() {
		mobile.clickOnTextListPreference();
	}

	@Then("First Option is selected")
	public void first_option_should_be_selected() { mobile.clickOnFirstTextButton();}

	@When("User clicks on text button")
	public void user_clicks_on_text_button() {
		mobile.clickOnTextButton();
	}

	@Then("User should be able to enter text")
	public void user_should_be_able_to_enter_text() {
		mobile.enterText();
	}


}