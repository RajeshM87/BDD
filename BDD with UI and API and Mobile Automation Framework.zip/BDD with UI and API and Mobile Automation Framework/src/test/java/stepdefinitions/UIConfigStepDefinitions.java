package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import com.pages.UIConfig;
import com.qa.factory.DriverFactory;

public class UIConfigStepDefinitions  {

	UIConfig uiconfig;	
	
	public UIConfigStepDefinitions(){
		uiconfig = new UIConfig(DriverFactory.getDriver());		
	}
	
	  @Given("^I am on the Login page URL$") 
	  public void i_am_on_the_Login_page_URL() throws Throwable { 
		  uiconfig.launchapp();	  
	  }
	  
	  @When("^I should see Sign In Page$")
	  public void i_should_see_Sign_In_Page() throws Throwable { 
		  uiconfig.userNameDisplay(); 
	  }
	  
	  @And("^I enter username$") 
	  public void i_enter_username() throws Throwable {
	  uiconfig.enterUserName(); 
	  }
	  
	  @And("^Enter username and pwd for \"([^\"]*)\" using excel$") 
	  public void enter_username_and_pwd_using_excel(String TCID) throws Throwable {
	  uiconfig.enterusernameandpwdusingexcel(TCID); 
	  }
	  
	  @And("^Enter username and pwd for \"([^\"]*)\" using fillo$") 
	  public void enter_username_and_pwd_using_fillo(String TCID) throws Throwable {
	  uiconfig.enterusernameandpwdusingfillo(TCID); 
	  }
	  
	  @And("^Enter username and pwd for \"([^\"]*)\" using json$") 
	  public void enter_username_and_pwd_using_json(String TCID) throws Throwable {
	  uiconfig.enterusernameandpwdusingjson(TCID); 
	  }
	  
	  @And("^I enter password$") 
	  public void i_enter_password() throws Throwable {
	  uiconfig.enterPassword(); 
	  }
	  
	  @And("^Click on login button$") 
	  public void click_on_login_button() throws Throwable { 
	  uiconfig.clickLoginButton(); 
	  }	
	
	  @Then("^Click on logout button$") 
	  public void click_on_logout_button() throws Throwable { 
	  uiconfig.clickLogoutButton(); 
	  }

	
}