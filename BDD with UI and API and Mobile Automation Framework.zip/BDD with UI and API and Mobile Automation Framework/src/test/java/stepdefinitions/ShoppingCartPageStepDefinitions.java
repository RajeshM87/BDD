package stepdefinitions;

import helper.WaitHelper;
import io.cucumber.java.en.Then;
import com.pages.ShoppingCartPage;
import com.qa.factory.DriverFactory;

public class ShoppingCartPageStepDefinitions  {

	ShoppingCartPage shoppingcartstepdef;
	WaitHelper waitHelper;
	
	public ShoppingCartPageStepDefinitions(){
		shoppingcartstepdef = new ShoppingCartPage(DriverFactory.getDriver());
		waitHelper = new WaitHelper(DriverFactory.getDriver());	
	}

	@Then("^I clicked on CheckOut button$")
	public void click_On_CheckOut() throws Throwable {
		shoppingcartstepdef.clickOnCheckOut();
	}	
}