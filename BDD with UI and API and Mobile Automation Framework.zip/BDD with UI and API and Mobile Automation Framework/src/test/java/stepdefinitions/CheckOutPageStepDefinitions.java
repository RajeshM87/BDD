package stepdefinitions;

import helper.WaitHelper;
import io.cucumber.java.en.Then;

import com.pages.CheckOutPage;
import com.qa.factory.DriverFactory;

public class CheckOutPageStepDefinitions  {

	CheckOutPage checkoutpagestepdef;
	WaitHelper waitHelper;
	
	public CheckOutPageStepDefinitions(){
		checkoutpagestepdef = new CheckOutPage(DriverFactory.getDriver());
		waitHelper = new WaitHelper(DriverFactory.getDriver());	
	}	
	
	@Then("^Provide the Order details using Json$")
	public void enter_order_data_using_json() throws Throwable {
		checkoutpagestepdef.enterOrderDataUsingJson();
	}
	
	@Then("^Provide the Order details using Fillo$")
	public void enter_order_data_using_fillo() throws Throwable {
		checkoutpagestepdef.enterOrderDataUsingFillo();
	}
	
	@Then("^Provide the Order details using Excel$")
	public void enter_order_data_using_excel() throws Throwable {
		checkoutpagestepdef.enterOrderDataUsingExcel();
	}
	
	@Then("^Enter Multiple Order Data for \"([^\"]*)\" using Excel$") 
	public void enter_multiple_order_data_using_excel(String TCID) throws Throwable 
	{
	  checkoutpagestepdef.enterMultipleOrderDataUsingExcel(TCID); 
	}
	  
	@Then("^Enter Multiple Order Data for \"([^\"]*)\" using Json$")
	public void enter_multiple_order_data_using_json(String TCID) throws Throwable 
	{
	  checkoutpagestepdef.enterMultipleOrderDataUsingJson(TCID); 
	}
	  
	@Then("^Enter Multiple Order Data for \"([^\"]*)\" using Fillo$")
	public void enter_multiple_order_data_using_fillo(String TCID) throws Throwable 
	{
	  checkoutpagestepdef.enterMultipleOrderDataUsingFillo(TCID); 
	}	 
	
	@Then("^I clicked on Continue button$")
	public void click_On_Continue() throws Throwable {
		checkoutpagestepdef.clickOnContinue();
	}
	
	@Then("^I clicked on Finish button$")
	public void click_On_Finish() throws Throwable {
		checkoutpagestepdef.clickOnFinish();
	}
	
	@Then("^Verify the Order placed success message$")
	public void verify_The_Order_Placed_Message() throws Throwable {
		checkoutpagestepdef.verifyTheOrderPlacedMessage();
	}
			
}