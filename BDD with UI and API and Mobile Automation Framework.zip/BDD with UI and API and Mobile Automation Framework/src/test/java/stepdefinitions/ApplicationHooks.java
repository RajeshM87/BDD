package stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Properties;

import com.qa.util.ConfigReader;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.qa.factory.DriverFactory;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;


public class ApplicationHooks {

	private DriverFactory driverFactory;
	private WebDriver driver;
	private ConfigReader configReader;
	Properties prop;
	public static AppiumDriverLocalService service;
	private final static Logger LOGGER = 
            Logger.getLogger(ApplicationHooks.class);

	@Before(order = 0)
	public void getProperty() {
		 configReader = new ConfigReader();
		 prop = configReader.init_prop("config.properties");
	}

	@Before(order = 1)
	//@Before
	public void launchBrowserOrApp() throws IOException, InterruptedException {
		if(prop.getProperty("automation").equalsIgnoreCase("mobile")) {
			if (prop.getProperty("platform").equalsIgnoreCase("local"))
				service = startServer();

			driverFactory = new DriverFactory();
			this.driver = driverFactory.init_mobile_driver(prop.getProperty("platform"));
		}
		else if(prop.getProperty("automation").equalsIgnoreCase("web")) {
			String browserName = prop.getProperty("browser");
			driverFactory = new DriverFactory();
			this.driver = driverFactory.init_driver(browserName);
		}
	}

	@AfterStep
	public void endStep(Scenario scenario)
	{
		if(prop.getProperty("automation").equalsIgnoreCase("api")){
			LOGGER.log(Level.INFO,"Screenshot not required for API execution...");
		}
		else
		{
			if (scenario.isFailed()) {
				try {
					LOGGER.info(scenario.getName() + " is Failed");
					final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
					scenario.attach(screenshot, "image/png", "Scenario Failed"); // ... and embed it in
				} catch (WebDriverException e) {
					e.printStackTrace();
				}

			} else {
				try {
					LOGGER.info(scenario.getName() + " is Passed");
					scenario.attach(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png", "Scenario Passed");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	@After(order = 0)
	public void quitBrowserOrServer() {
		if(prop.getProperty("automation").equalsIgnoreCase("api")){
			LOGGER.log(Level.INFO,"Browser not required to quit for API execution...");
		}
		else if(prop.getProperty("automation").equalsIgnoreCase("mobile")){
			if(prop.getProperty("platform").equalsIgnoreCase("local")) {
				stopServer();
				driver.quit();
			}
			else{
				LOGGER.log(Level.INFO,"Server running in remote machine...");
				driver.quit();
			}
		}
		else {
			driver.quit();
		}
	}

	public static String capture(WebDriver driver) throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("target/cucumber-reports/Screenshots/failedsnap_" + System.currentTimeMillis() + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	public AppiumDriverLocalService startServer()
	{
		//
		boolean flag = checkIfServerIsRunnning(4723);
		if(!flag)
		{

			service=AppiumDriverLocalService.buildDefaultService();
			service.start();
		}
		return service;

	}

	public static boolean checkIfServerIsRunnning(int port) {

		boolean isServerRunning = false;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(port);

			serverSocket.close();
		} catch (IOException e) {
			//If control comes here, then it means that the port is in use
			isServerRunning = true;
		} finally {
			serverSocket = null;
		}
		return isServerRunning;
	}

	public void stopServer()
	{
		service.stop();
	}

	  @After(order = 1) public void tearDown(Scenario scenario) { if
	  (scenario.isFailed()) {
		  String screenshotName = scenario.getName().replaceAll(" ", "_");
		  byte[] sourcePath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		  scenario.attach(sourcePath, "image/png", screenshotName);
	  } }

}
