package helper;

public interface FrameworkConstants {
	
	public static final String CONFIG_FILE_PATH = "./src/test/resources/config/api.properties";
	public static final String POSTRequest_AUTH_DEFAULT_REQUEST = "./src/test/resources/testData/PostRequest_Auth.txt";
	public static final String DATA_FILE_PATH = "./src/test/resources/testData/APITestData.xlsx";
	
}
