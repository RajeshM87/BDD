package com.qa.util;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ReadJson {

	public static JSONObject jsonObject = null;
	
	public static JSONObject readjson(String data) {
		JSONParser parser = new JSONParser();	
		
		try {
			Object obj = parser.parse(new FileReader(System.getProperty("user.dir") + data));
 
			// A JSON object. Key value pairs are unordered. JSONObject supports java.util.Map interface.
			jsonObject = (JSONObject) obj;	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	public void setvalue(String key,String rootkey,String Parentkey, String value)
	{
		jsonObject.put(key,value);
		jsonObject.remove(key,value);
//		jsonObject.getJSONObject(Parentkey).put(key,value);
		//jsonObject.getJSONArray(rootkey).getJSONObject(Parentkey).put(key,value);
		
	}	
}
