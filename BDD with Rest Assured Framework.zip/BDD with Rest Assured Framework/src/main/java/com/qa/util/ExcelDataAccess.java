package com.qa.util;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import helper.FrameworkConstants;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.hssf.util.CellRangeAddress;	not used because this is deprecated


/**
 * Class to encapsulate the excel data access layer of the framework
 * @author 
 */
public class ExcelDataAccess
{
	private Workbook workbook;
	private Sheet worksheet;
	private Row row;
	private Cell cell;
	private int rows;
	private String testCaseName;
	private int testCaseStartRow = 0;
	private int testCaseEndRow=0;
	private int usedColumnsCount = 0;
	private int iterationCount = 0;

	private String filePath = null;
	private String fileName = null;
	
	private String datasheetName;
	/**
	 * Function to get the Excel sheet name
	 * @return The Excel sheet name
	 */
	public String getDatasheetName()
	{
		return datasheetName;
	}
	/**
	 * Function to set the Excel sheet name
	 * @param datasheetName The Excel sheet name
	 */
	public void setDatasheetName(String datasheetName)
	{
		this.datasheetName = datasheetName;
	}
	
	
	/**
	 * Constructor to initialize the excel data filepath and filename
	 * @param filePath The absolute path where the excel data file is stored
	 * @param fileName The name of the excel data file (without the extension).
	 * Note that .xlsx files are not supported, only .xls files are supported
	 */
	public ExcelDataAccess(String filePath, String fileName)
	{
		this.filePath = filePath;
		this.fileName = fileName;
	}

	public ExcelDataAccess(String workSheetName, String testCaseName, String name) throws Exception{
		//excelLibNew xl = new excelLibNew("Quote_EBGeoRedundantHeadEndOnly", "Quote_EBHeadEndOnly");
		System.out.println("workSheetName name is : "+workSheetName);
		System.out.println("testCaseName name is : "+testCaseName);
		System.out.println("Name is : "+name);
//		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\Test_Data\\TestData.xlsx");
		FileInputStream fis = new FileInputStream(FrameworkConstants.DATA_FILE_PATH);
		workbook = new XSSFWorkbook(fis);

		worksheet = workbook.getSheet(workSheetName);

		System.out.println("Sheet name is : "+ worksheet.getSheetName());
		this.testCaseName = testCaseName;
		rows = getRowCount();
		testCaseStartRow = getTestCaseStartRow();
		testCaseEndRow = getTestCaseEndRow();
		usedColumnsCount = getUsedColumnsCount();
		System.out.println("usedColumnsCount+1 is "+usedColumnsCount);
		iterationCount = getIterationCount();
	}

	/*Gets the total number of row count in the excel sheet*/
	private int getRowCount() {

		System.out.println("worksheet.getLastRowNum : "+worksheet.getLastRowNum());
		System.out.println("worksheet.getFirstRowNum : "+worksheet.getFirstRowNum());
		int rowCount = worksheet.getLastRowNum()-worksheet.getFirstRowNum();
		System.out.println("getRowCount is : "+rowCount);
		return rowCount;
	}


	/*Get TestCase Start Row*/
	private int getTestCaseStartRow(){
		try {
			for(int i = 1; i <= rows; i++){

				row = worksheet.getRow(i);
				cell=row.getCell(0);
				System.out.println("cell String is : "+cell.getStringCellValue());
				System.out.println("test case name is : "+testCaseName);
				if(cell.getStringCellValue().equals(testCaseName.trim())){
					testCaseStartRow = i;
					System.out.println("testCaseStartRow is : "+testCaseStartRow);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testCaseStartRow;
	}

	/*Get Test Case End Row*/
	private int getTestCaseEndRow(){
		try {

			for(int i = testCaseStartRow; i <= rows; i++){
				testCaseEndRow  = i;
				row = worksheet.getRow(i);
				cell=row.getCell(0);
				System.out.println("cell.getStringCellValue() : "+cell.getStringCellValue());
				System.out.println("testCaseName.trim() : "+testCaseName.trim());
				if(!cell.getStringCellValue().equals(testCaseName.trim())){
					testCaseEndRow  = i-1;
					System.out.println("testCaseEndRow is : "+testCaseEndRow);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testCaseEndRow;
	}

	/*Get the Columns Count for the referenced test case*/

	private int getUsedColumnsCount(){
		try {
			int count = 0;

			row = worksheet.getRow(testCaseStartRow);

			while(! row.getCell(count).getStringCellValue().equalsIgnoreCase("EndRow")){
				usedColumnsCount = count++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("usedColumnsCount is : "+usedColumnsCount);
		return (usedColumnsCount+1);
	}

	private int getIterationCount(){
		try {
			for(int i =testCaseStartRow; i <= testCaseEndRow; i++){

				row = worksheet.getRow(i);

				if(row.getCell(1).getStringCellValue().equalsIgnoreCase("Yes")){
//					System.out.println("Execute column value is : "+row.getCell(usedColumnsCount).getStringCellValue());
					iterationCount++;
				}

			}
			System.out.println("Total no. of test case iteration is : "+iterationCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(iterationCount > 0){
			System.out.println("Total Number of Rows Selected is "+iterationCount);
		}else{
			System.out.println("*************************************************************************************");
			System.out.println("Total Number of Rows Selected is 0. Please Check Execute Column in TestData.xls file");
			System.out.println("*************************************************************************************");
		}

		return iterationCount;
	}


	/*Return Two Dimensional Array to DataProvider*/
	public Object[][] getTestdata(){
		int rowNum = 0;
		int colNum = 0;
		String data[][] = new String[iterationCount][usedColumnsCount-1];

		//Get the Test Data
		for(int i =testCaseStartRow; i <= testCaseEndRow; i++){
			colNum = 0;
			boolean flag = false;

			row = worksheet.getRow(i);

			if(row.getCell(1).getStringCellValue().equalsIgnoreCase("Yes")){
				flag = true;
				for(int j = 2; j < usedColumnsCount; j++){
					System.out.println("Cell content is : "+row.getCell(j).getStringCellValue());
					data[rowNum][colNum] = row.getCell(j).getStringCellValue();
					colNum++;
				}
			}
			if(flag){
				rowNum++;
			}
		}

		return data;
	}
	
	private void checkPreRequisites()
	{
		if(datasheetName == null) {
			throw new FrameworkException("ExcelDataAccess.datasheetName is not set!");
		}
	}
	
	private HSSFWorkbook openFileForReading()
	{
		String absoluteFilePath = filePath + APIUtility.getFileSeparator() +
															fileName + ".xls";
		
		FileInputStream fileInputStream;
		try	{
			fileInputStream = new FileInputStream(absoluteFilePath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new FrameworkException("The specified file \"" + absoluteFilePath + "\" does not exist!");
		}
		
		HSSFWorkbook workbook;
		try {
			workbook = new HSSFWorkbook(fileInputStream);
			//fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new FrameworkException("Error while opening the specified Excel workbook \"" + absoluteFilePath + "\"");
		}
		
		return workbook;
	}
	
	private void writeIntoFile(HSSFWorkbook workbook)
	{
		String absoluteFilePath = filePath + APIUtility.getFileSeparator() +
															fileName + ".xls";
		
		FileOutputStream fileOutputStream;
		try	{
			fileOutputStream = new FileOutputStream(absoluteFilePath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new FrameworkException("The specified file \"" + absoluteFilePath + "\" does not exist!");
		}
		
		try {
			workbook.write(fileOutputStream);
			fileOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new FrameworkException("Error while writing into the specified Excel workbook \"" + absoluteFilePath + "\"");
		}
	}
	
	private HSSFSheet getWorkSheet(HSSFWorkbook workbook)
	{
		HSSFSheet worksheet = workbook.getSheet(datasheetName);
		if (worksheet == null) {
			throw new FrameworkException("The specified sheet \"" + datasheetName + "\"" +
										"does not exist within the workbook \"" + fileName + ".xls\"");
		}
		
		return worksheet;
	}
	
	/**
	 * Function to search for a specified key within a column, and return the corresponding row number
	 * @param key The value being searched for
	 * @param columnNum The column number in which the key should be searched
	 * @param startRowNum The row number from which the search should start
	 * @return The row number in which the specified key is found (-1 if the key is not found)
	 */
	public int getRowNum(String key, int columnNum, int startRowNum)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		String currentValue;
		for (int currentRowNum = startRowNum;
				currentRowNum <= worksheet.getLastRowNum(); currentRowNum++) {
			
			HSSFRow row = worksheet.getRow(currentRowNum);
			HSSFCell cell = row.getCell(columnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);
			
			if (currentValue.equals(key)) {
				return currentRowNum;
			}
		}
		
		return -1;
	}
	
	/*private String getCellValueAsString(HSSFCell cell, FormulaEvaluator formulaEvaluator)
	{
		if (cell == null) {
			return "";
		} else {
			switch(formulaEvaluator.evaluate(cell).getCellType()) {
			case HSSFCell.CELL_TYPE_BLANK:
			case HSSFCell.CELL_TYPE_STRING:
				System.out.print("string: ");
				return cell.getStringCellValue().trim();
				
			case HSSFCell.CELL_TYPE_BOOLEAN:
				System.out.print("bool: ");
				return Boolean.toString(cell.getBooleanCellValue());
				
			case HSSFCell.CELL_TYPE_NUMERIC:
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					System.out.print("date: ");
					return cell.getDateCellValue().toString();
				} else {
					System.out.print("numeric: ");
					return Double.toString(cell.getNumericCellValue());
				}
				
			case HSSFCell.CELL_TYPE_ERROR:
				System.out.print("error: ");
				throw new FrameworkException("Error in formula within this cell! " +
													"Error code: " + cell.getErrorCellValue());
				
			//case HSSFCell.CELL_TYPE_FORMULA:
				// This will never occur!
				
			default:
				throw new FrameworkException("Unhandled cell type!");
			}
		}
	}*/
	
	private String getCellValueAsString(HSSFCell cell, FormulaEvaluator formulaEvaluator)
	{
		if (cell == null || cell.getCellType() == cell.getCellType().BLANK) {
			return "";
		} else {
			if (formulaEvaluator.evaluate(cell).getCellType() == cell.getCellType().ERROR) {
				throw new FrameworkException("Error in formula within this cell! " +
											"Error code: " + cell.getErrorCellValue());
			}
			
			DataFormatter dataFormatter = new DataFormatter();
			return dataFormatter.formatCellValue(formulaEvaluator.evaluateInCell(cell));
		}
	}
	
	/**
	 * Function to search for a specified key within a column, and return the corresponding row number
	 * @param key The value being searched for
	 * @param columnNum The column number in which the key should be searched
	 * @return The row number in which the specified key is found (-1 if the key is not found)
	 */
	public int getRowNum(String key, int columnNum)
	{
		return getRowNum(key, columnNum, 0);
	}
	
	/**
	 * Function to get the last row number within the worksheet
	 * @return The last row number within the worksheet
	 */
	public int getLastRowNum()
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		return worksheet.getLastRowNum();
	}
	
	/**
	 * Function to search for a specified key within a column, and return the corresponding occurence count
	 * @param key The value being searched for
	 * @param columnNum The column number in which the key should be searched
	 * @param startRowNum The row number from which the search should start
	 * @return The occurence count of the specified key
	 */
	public int getRowCount(String key, int columnNum, int startRowNum)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		int rowCount = 0;
		Boolean keyFound = Boolean. valueOf(false) ;
		
		String currentValue;
		for (int currentRowNum = startRowNum;
				currentRowNum <= worksheet.getLastRowNum(); currentRowNum++) {
			String currentRowValue = getCellValue(worksheet, currentRowNum, columnNum) ;
			if (currentRowValue.equals(key)) {
			//rowCount++3.
			rowCount = currentRowNum;
			keyFound = Boolean. valueOf(true) ;
		
			} else {
				if (keyFound.booleanValue()) {
					break;	// Assumption: Keys always appear contiguously
				}
			}
		}
		
		return rowCount;
	}
	
	/**
	 * Function to search for a specified key within a column, and return the corresponding occurence count
	 * @param key The value being searched for
	 * @param columnNum The column number in which the key should be searched
	 * @return The occurence count of the specified key
	 */
	public int getRowCount(String key, int columnNum)
	{
		return getRowCount(key, columnNum, 0);
	}
	
	/**
	 * Function to search for a specified key within a row, and return the corresponding column number
	 * @param key The value being searched for
	 * @param rowNum The row number in which the key should be searched
	 * @return The column number in which the specified key is found (-1 if the key is not found)
	 */
	public int getColumnNum(String key, int rowNum)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		HSSFRow row = worksheet.getRow(rowNum);
		String currentValue;
		for (int currentColumnNum = 0;
				currentColumnNum < row.getLastCellNum(); currentColumnNum++) {
			
			HSSFCell cell = row.getCell(currentColumnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);
			
			if (currentValue.equals(key)) {
				return currentColumnNum;
			}
		}
		
		return -1;
	}
	
	private String getCellValue(HSSFSheet worksheet, int rowNum, int columnNum) {
		String cellValue;
		HSSFRow row = worksheet.getRow(rowNum) ;
		HSSFCell cell = row.getCell(columnNum) ;
		if (cell == null) {
		cellValue = "";
		} else {
		cellValue = cell. getStringCellValue().trim();
		}
		return cellValue;

	}

	private String getCellValue(HSSFSheet worksheet, HSSFRow row, int columnNum) {
		String cellValue;
		HSSFCell cell = row.getCell(columnNum) ;
		if (cell == null) {
		cellValue = "";
		} else {
		cellValue = cell. getStringCellValue().trim();
		}

		return cellValue;
	}
	
	/**
	 * Function to get the value in the cell identified by the specified row and column numbers
	 * @param rowNum The row number of the cell
	 * @param columnNum The column number of the cell
	 * @return The value present in the cell
	 */
	public String getValue(int rowNum, int columnNum)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		HSSFRow row = worksheet.getRow(rowNum);
		HSSFCell cell = row.getCell(columnNum);
		return getCellValueAsString(cell, formulaEvaluator);
	}
	
	/**
	 * Function to get the value in the cell identified by the specified row number and column header
	 * @param rowNum The row number of the cell
	 * @param columnHeader The column header of the cell
	 * @return The value present in the cell
	 */
	public String getValue(int rowNum, String columnHeader)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		HSSFRow row = worksheet.getRow(0);	//0 because header is always in the first row
		int columnNum = -1;
		String currentValue;
		for (int currentColumnNum = 0;
				currentColumnNum < row.getLastCellNum(); currentColumnNum++) {
			
			HSSFCell cell = row.getCell(currentColumnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);
			
			if (currentValue.equals(columnHeader)) {
				columnNum = currentColumnNum;
				break;
			}
		}
		
		if (columnNum == -1) {
			throw new FrameworkException("The specified column header \"" + columnHeader + "\"" +
										"is not found in the sheet \"" + datasheetName + "\"!");
		} else {
			row = worksheet.getRow(rowNum);
			HSSFCell cell = row.getCell(columnNum);
			return getCellValueAsString(cell, formulaEvaluator);
		}
	}
	
	private HSSFCellStyle applyCellStyle(HSSFWorkbook workbook,
											ExcelCellFormatting cellFormatting)
	{
		HSSFCellStyle cellStyle = workbook.createCellStyle();
		if (cellFormatting.centred) {
			//cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		}
		cellStyle.setFillForegroundColor(cellFormatting.getBackColorIndex());
		//cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		
		HSSFFont font = workbook.createFont();
		font.setFontName(cellFormatting.getFontName());
		font.setFontHeightInPoints(cellFormatting.getFontSize());
		if (cellFormatting.bold) {
			//font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		}
		font.setColor(cellFormatting.getForeColorIndex());
		cellStyle.setFont(font);
		
		return cellStyle;
	}
	
	/**
	 * Function to set the specified value in the cell identified by the specified row and column numbers
	 * @param rowNum The row number of the cell
	 * @param columnNum The column number of the cell
	 * @param value The value to be set in the cell
	 */
	public void setValue(int rowNum, int columnNum, String value)
	{
		setValue(rowNum, columnNum, value, null);
	}
	
	/**
	 * Function to set the specified value in the cell identified by the specified row and column numbers
	 * @param rowNum The row number of the cell
	 * @param columnNum The column number of the cell
	 * @param value The value to be set in the cell
	 * @param cellFormatting The {@link ExcelCellFormatting} to be applied to the cell
	 */
	public void setValue(int rowNum, int columnNum, String value,
											ExcelCellFormatting cellFormatting)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		HSSFRow row = worksheet.getRow(rowNum);
		HSSFCell cell = row.createCell(columnNum);
		//cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(value);
		
		if (cellFormatting != null) {
			HSSFCellStyle cellStyle = applyCellStyle(workbook, cellFormatting);
			cell.setCellStyle(cellStyle);
		}
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to set the specified value in the cell identified by the specified row number and column header
	 * @param rowNum The row number of the cell
	 * @param columnHeader The column header of the cell
	 * @param value The value to be set in the cell
	 */
	public void setValue(int rowNum, String columnHeader, String value)
	{
		setValue(rowNum, columnHeader, value, null);
	}
	
	/**
	 * Function to set the specified value in the cell identified by the specified row number and column header
	 * @param rowNum The row number of the cell
	 * @param columnHeader The column header of the cell
	 * @param value The value to be set in the cell
	 * @param cellFormatting The {@link ExcelCellFormatting} to be applied to the cell
	 */
	public void setValue(int rowNum, String columnHeader, String value,
												ExcelCellFormatting cellFormatting)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		HSSFRow row = worksheet.getRow(0);	//0 because header is always in the first row
		int columnNum = -1;
		String currentValue;
		for (int currentColumnNum = 0;
				currentColumnNum < row.getLastCellNum(); currentColumnNum++) {
			
			HSSFCell cell = row.getCell(currentColumnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);
			
			if (currentValue.equals(columnHeader)) {
				columnNum = currentColumnNum;
				break;
			}
		}
		
		if (columnNum == -1) {
			throw new FrameworkException("The specified column header \"" + columnHeader + "\"" +
										"is not found in the sheet \"" + datasheetName + "\"!");
		} else {
			row = worksheet.getRow(rowNum);
			HSSFCell cell = row.createCell(columnNum);
			//cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(value);
			
			if (cellFormatting != null) {
				HSSFCellStyle cellStyle = applyCellStyle(workbook, cellFormatting);
				cell.setCellStyle(cellStyle);
			}
			
			writeIntoFile(workbook);
		}
	}
	
	/**
	 * Function to set a hyperlink in the cell identified by the specified row and column numbers
	 * @param rowNum The row number of the cell
	 * @param columnNum The column number of the cell
	 * @param linkAddress The link address to be set
	 */
	public void setHyperlink(int rowNum, int columnNum, String linkAddress)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		HSSFRow row = worksheet.getRow(rowNum);
		HSSFCell cell = row.getCell(columnNum);
		if (cell == null) {
			throw new FrameworkException("Specified cell is empty! " +
										"Please set a value before including a hyperlink...");
		}
		
		setCellHyperlink(workbook, cell, linkAddress);
		
		writeIntoFile(workbook);
	}
	
	private void setCellHyperlink(HSSFWorkbook workbook, HSSFCell cell, String linkAddress)
	{
		HSSFCellStyle cellStyle = cell.getCellStyle();
		HSSFFont font = cellStyle.getFont(workbook);
		font.setUnderline(HSSFFont.U_SINGLE);
		cellStyle.setFont(font);
		
		CreationHelper creationHelper = workbook.getCreationHelper();
		//Hyperlink hyperlink = creationHelper.createHyperlink(Hyperlink.LINK_URL);
		//hyperlink.setAddress(linkAddress);
		
		cell.setCellStyle(cellStyle);
		//cell.setHyperlink(hyperlink);
	}
	
	/**
	 * Function to set a hyperlink in the cell identified by the specified row number and column header
	 * @param rowNum The row number of the cell
	 * @param columnHeader The column header of the cell
	 * @param linkAddress The link address to be set
	 */
	public void setHyperlink(int rowNum, String columnHeader, String linkAddress)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		FormulaEvaluator formulaEvaluator =
							workbook.getCreationHelper().createFormulaEvaluator();
		
		HSSFRow row = worksheet.getRow(0);	//0 because header is always in the first row
		int columnNum = -1;
		String currentValue;
		for (int currentColumnNum = 0;
				currentColumnNum < row.getLastCellNum(); currentColumnNum++) {
			
			HSSFCell cell = row.getCell(currentColumnNum);
			currentValue = getCellValueAsString(cell, formulaEvaluator);
			
			if (currentValue.equals(columnHeader)) {
				columnNum = currentColumnNum;
				break;
			}
		}
		
		if (columnNum == -1) {
			throw new FrameworkException("The specified column header \"" + columnHeader + "\"" +
										"is not found in the sheet \"" + datasheetName + "\"!");
		} else {
			row = worksheet.getRow(rowNum);
			HSSFCell cell = row.getCell(columnNum);
			if (cell == null) {
				throw new FrameworkException("Specified cell is empty! " +
											"Please set a value before including a hyperlink...");
			}
			
			setCellHyperlink(workbook, cell, linkAddress);
			
			writeIntoFile(workbook);
		}
	}
	
	/**
	 * Function to create a new Excel workbook
	 */
	public void createWorkbook()
	{
		HSSFWorkbook workbook = new HSSFWorkbook();
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to add a sheet to the Excel workbook
	 * @param sheetName The sheet name to be added
	 */
	public void addSheet(String sheetName)
	{
		HSSFWorkbook workbook = openFileForReading();
		
		HSSFSheet worksheet = workbook.createSheet(sheetName);
		worksheet.createRow(0);	//include a blank row in the sheet created
		
		writeIntoFile(workbook);
		
		this.datasheetName = sheetName;
	}
	
	/**
	 * Function to add a new row to the Excel worksheet
	 * @return The row number of the newly added row
	 */
	public int addRow()
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		int newRowNum = worksheet.getLastRowNum() + 1;
		worksheet.createRow(newRowNum);
		
		writeIntoFile(workbook);
		
		return newRowNum;
	}
	
	/**
	 * Function to add a new column to the Excel worksheet
	 * @param columnHeader The column header to be added
	 */
	public void addColumn(String columnHeader)
	{
		addColumn(columnHeader, null);
	}
	
	/**
	 * Function to add a new column to the Excel worksheet
	 * @param columnHeader The column header to be added
	 * @param cellFormatting The {@link ExcelCellFormatting} to be applied to the column header
	 */
	public void addColumn(String columnHeader, ExcelCellFormatting cellFormatting)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		HSSFRow row = worksheet.getRow(0);	//0 because header is always in the first row
		int lastCellNum = row.getLastCellNum();
		if (lastCellNum == -1) {
			lastCellNum = 0;
		}
		
		HSSFCell cell = row.createCell(lastCellNum);
		//cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(columnHeader);
		
		if (cellFormatting != null) {
			HSSFCellStyle cellStyle = applyCellStyle(workbook, cellFormatting);
			cell.setCellStyle(cellStyle);
		}
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to set a specified color at the specified index within the custom palette
	 * @param index The index at which the color should be set within the palette
	 * @param hexColor The hex value of the color to be set within the palette
	 */
	public void setCustomPaletteColor(short index, String hexColor)
	{
		HSSFWorkbook workbook = openFileForReading();
		HSSFPalette palette = workbook.getCustomPalette();
		
		if(index < 0x8 || index > 0x40) {
			throw new FrameworkException("Valid indexes for the Excel custom palette are from 0x8 to 0x40 (inclusive)!");
		}
		
		Color color = Color.decode(hexColor);
		palette.setColorAtIndex(index, (byte) color.getRed(),
									(byte) color.getGreen(), (byte) color.getBlue());
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to merge the specified range of cells
	 * (all inputs are 0-based)
	 * @param firstRow The first row 
	 * @param lastRow The last row
	 * @param firstCol The first column
	 * @param lastCol The last column
	 */
	public void mergeCells(int firstRow, int lastRow, int firstCol, int lastCol)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		CellRangeAddress cellRangeAddress = new CellRangeAddress(firstRow, lastRow,
																	firstCol, lastCol);
		worksheet.addMergedRegion(cellRangeAddress);
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to specify whether the row summaries appear below the detail
	 * within an outline (grouped set of rows)
	 * @param rowSumsBelow Boolean value to specify row summaries below detail
	 * within an outline
	 */
	public void setRowSumsBelow(boolean rowSumsBelow)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		worksheet.setRowSumsBelow(rowSumsBelow);
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to outline (i.e., group together) the specified rows
	 * @param firstRow The first row
	 * @param lastRow The last row
	 */
	public void groupRows(int firstRow, int lastRow)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		worksheet.groupRow(firstRow, lastRow);
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to automatically adjust the column width to fit the contents
	 * for the specified range of columns (all inputs are 0-based)
	 * @param firstCol The first column
	 * @param lastCol The last column
	 */
	public void autoFitContents(int firstCol, int lastCol)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		if (firstCol < 0) {
			firstCol = 0;
		}
		
		if (firstCol > lastCol) {
			throw new FrameworkException("First column cannot be greater than last column!");
		}
		
		for (int currentColumn = firstCol;
					currentColumn <= lastCol; currentColumn++) {
			worksheet.autoSizeColumn(currentColumn);
		}
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to add an outer border around the specified range of columns
	 * (all inputs are 0-based)
	 * @param firstCol The first column
	 * @param lastCol The last column
	 */
	public void addOuterBorder(int firstCol, int lastCol)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		CellRangeAddress cellRangeAddress = new CellRangeAddress(0, worksheet.getLastRowNum(),
																	firstCol, lastCol);
		//HSSFRegionUtil.setBorderBottom(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		//HSSFRegionUtil.setBorderRight(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		
		writeIntoFile(workbook);
	}
	
	/**
	 * Function to add an outer border around the specified range of columns
	 * (all inputs are 0-based)
	 * @param firstRow The first row 
	 * @param lastRow The last row
	 * @param firstCol The first column
	 * @param lastCol The last column
	 */
	public void addOuterBorder(int firstRow, int lastRow, int firstCol, int lastCol)
	{
		checkPreRequisites();
		
		HSSFWorkbook workbook = openFileForReading();
		HSSFSheet worksheet = getWorkSheet(workbook);
		
		CellRangeAddress cellRangeAddress = new CellRangeAddress(firstRow, lastRow,
																	firstCol, lastCol);
		//HSSFRegionUtil.setBorderBottom(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		//HSSFRegionUtil.setBorderTop(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		//HSSFRegionUtil.setBorderRight(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		//HSSFRegionUtil.setBorderLeft(HSSFCellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
		
		writeIntoFile(workbook);
	}
}