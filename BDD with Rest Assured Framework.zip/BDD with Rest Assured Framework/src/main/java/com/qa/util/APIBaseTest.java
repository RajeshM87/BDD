package com.qa.util;

import helper.AllureLogger;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public abstract class APIBaseTest extends APIUtility {
	
	protected static RequestSpecification requestSpec;
	protected static ResponseSpecification responseSpec;

	public APIBaseTest() {
		setBaseURI();
		responseMethod();
	}
	public void setBaseURI() {
		
        AllureLogger.logToAllure("The base URI is : "+readConfigurationFile("Base_URI"));
		//LOGGER.log(Level.INFO,"The base URI is : "+readConfigurationFile("Base_URI"));
		requestSpec = new RequestSpecBuilder().
                		setBaseUri(readConfigurationFile("Base_URI")).
                		build();
		//LOGGER.log(Level.INFO,"Request Specification is : "+ requestSpec);
        
	}

	public void responseMethod() {

		responseSpec = new ResponseSpecBuilder().expectStatusCode(200).build();
		//LOGGER.log(Level.INFO,"Response Specification is : "+ responseSpec);

	}
}
