package com.apiClasses;

import com.qa.util.APIBaseTest;
import com.qa.util.ReadJson;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.logging.Level;

import static com.qa.util.ReadJson.jsonObject;

public class testapi extends APIBaseTest {

	public void testjson() throws IOException, ParseException {

		/*jsonObject = ReadJson.readjson("./src/test/resources/testData/GeneralData.json");
		JSONArray generalDataList = (JSONArray) jsonObject.get(TCID);

		@SuppressWarnings("unchecked")
		Iterator<JSONObject> iterator = generalDataList.iterator();
		while (iterator.hasNext()) {
			LOGGER.log(Level.INFO, "Iterator value:" + iterator.next());
		}

		for (Object o : generalDataList) {
			JSONObject generalData = (JSONObject) o;

			String username = (String) generalData.get("UserName");
			String password = (String) generalData.get("Password");
		}	*/

		JSONParser parser = new JSONParser();

		Object obj = parser.parse(new FileReader("./src/test/resources/testData/test.json"));
		jsonObject = (JSONObject) obj;
		System.out.println(jsonObject);

		JSONObject search = (JSONObject) jsonObject.get("search");
		JSONArray entry = (JSONArray) search.get("entry");

		for (int i = 0; i < entry.size(); i++) {

			JSONObject jsonObject1 = (JSONObject) entry.get(i);
			JSONArray jsonarray1 = (JSONArray) jsonObject1.get("attribute");
			//System.out.println(jsonarray1);

			for (int j = 0; j < jsonarray1.size(); j++) {
				((JSONObject) jsonarray1.get(j)).put("test","testvalue");
				((JSONObject) jsonarray1.get(j)).put("name","fname");
				System.out.println(jsonarray1);
				//JSONObject remove = (JSONObject) jsonarray1.remove(0);
				//JSONObject jsonObjectFromArray = (JSONObject) jsonarray1.get(j);
				//jsonObjectFromArray.remove(1);
				jsonarray1.remove(1);
				//((JSONObject) jsonarray1.get(j)).remove(0);
				//((JSONObject) jsonarray1.get(0)).remove(j);
				//((JSONObject) jsonarray1.get(1)).remove(0);
				//((JSONObject) jsonarray1.get(j)).remove(1);
				//((JSONObject) jsonarray1.get(1)).remove(j);
				//((JSONObject) jsonarray1.get(1)).remove(1);
				System.out.println(jsonObject1.toJSONString());
				System.out.println(jsonarray1.toJSONString());
				System.out.println(((JSONObject) jsonarray1.get(j)).get("value").toString());
			}
		}
		System.out.println(jsonObject);
	}
}
