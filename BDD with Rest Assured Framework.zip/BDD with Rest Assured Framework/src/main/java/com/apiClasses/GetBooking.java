package com.apiClasses;

import com.pojoClasses.BookingDetails;
import com.qa.util.APIBaseTest;
import com.qa.util.ExcelDataAccess;
import helper.AllureLogger;
import io.restassured.response.Response;

import java.util.logging.Level;

import static io.restassured.RestAssured.given;

public class GetBooking extends APIBaseTest {

	public static String FirstName;
	public static String LastName;
	public static String TotalPrice;
	public static String DepositPaid;
	public static String CheckIn;
	public static String CheckOut;
	public static String AdditionalNeeds;

	public void getBookingIDs(String TCID) throws Exception {
		CreateBooking createBooking = new CreateBooking();
		String IDtoGet = createBooking.newID;
		AllureLogger.logToAllure("Starting the test to get booking details");
		/*******************************************************
		 * Send a GET request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
		
		//Sending the GET request for a specific booking id and receiving the response
		AllureLogger.logToAllure("Getting the response for the Booking IDs from test data excel");

		ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", "APITestData");
		testdata.setDatasheetName("Booking");

		int rowNo = testdata.getRowCount(TCID, 0);

		FirstName = testdata.getValue(rowNo, "FirstName");
		LastName = testdata.getValue(rowNo, "LastName");
		TotalPrice = testdata.getValue(rowNo, "TotalPrice");
		DepositPaid = testdata.getValue(rowNo, "DepositPaid");
		CheckIn = testdata.getValue(rowNo, "CheckIn");
		CheckOut = testdata.getValue(rowNo, "CheckOut");
		AdditionalNeeds = testdata.getValue(rowNo, "AdditionalNeeds");

		Response response = given().
				spec(requestSpec).
				pathParam("id", IDtoGet).
			when().
				get("/booking/{id}");
		
		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200");
		response.then().spec(responseSpec);		

		//To log the response to report
		logResponseAsString(response);
		
		
		//Using the POJO class
		AllureLogger.logToAllure("Asserting of response body with the data from test data excel");
		AllureLogger.logToAllure("HTTP Status Code : "+response.statusCode());
		LOGGER.log(Level.INFO,"HTTP Status Code : "+response.statusCode());
		LOGGER.log(Level.INFO,"Get Operation performed successfully");

		BookingDetails bookingDetails = response.as(BookingDetails.class);
		LOGGER.log(Level.INFO, "First name is matched - "+ String.valueOf(bookingDetails.getFirstname().contains(FirstName)));
		LOGGER.log(Level.INFO, "Last name is matched - "+ String.valueOf(bookingDetails.getLastname().contains(LastName)));
		LOGGER.log(Level.INFO, "Additional Need is matched - "+ String.valueOf(bookingDetails.getAdditionalneeds().contains(AdditionalNeeds)));
		LOGGER.log(Level.INFO, "CheckIn Date is matched - "+ String.valueOf(bookingDetails.getBookingdates().getCheckin().contains(CheckIn)));
		LOGGER.log(Level.INFO, "CheckOut Date is matched - "+ String.valueOf(bookingDetails.getBookingdates().getCheckout().contains(CheckOut)));

	}
}
