package com.apiClasses;

import com.pojoClasses.BookingDetails;
import com.qa.util.APIBaseTest;
import helper.AllureLogger;
import io.restassured.response.Response;

import java.util.logging.Level;

import static io.restassured.RestAssured.given;

public class UpdateBooking extends APIBaseTest {
	
	public void updateBooking(String TCID) throws Exception{
		
		AllureLogger.logToAllure("Starting the test to update details");
		/*******************************************************
		 * Send a PUT request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
		
		//Sending the PUT request for a specific booking id and receiving the response after updating the detals
		AllureLogger.logToAllure("PUT update booking detail");
		
		//To get the auth token
		String newAuthToken = AuthToken.post_CreateAuth();
		AllureLogger.logToAllure("Auth token is : "+newAuthToken);
		
		//Created a new booking
		CreateBooking createBooking = new CreateBooking();
		String IDtoUpdate = createBooking.newID;
		AllureLogger.logToAllure("New Booking ID created is : "+IDtoUpdate);
		
		//Update the booking with new first name
		Response getResponse = given().
				spec(requestSpec).
				pathParam("id", IDtoUpdate).
			when().
				get("/booking/{id}");
		
		BookingDetails bookingDetails = getResponse.as(BookingDetails.class);
		bookingDetails.setFirstname("Tarly");
		bookingDetails.setLastname("Rachel");

		String cookieValue = "token="+newAuthToken;
		
		//Sending the PUT request
		AllureLogger.logToAllure("Sending the PUT request to update the booking detail of booking id : "+IDtoUpdate);
		Response response = given().
			spec(requestSpec).
			header("Content-Type", "application/json").
			header("Accept", "application/json").
			header("Cookie", cookieValue).
	        pathParam("id", IDtoUpdate).
	        body(bookingDetails).log().body().
	    when().
			put("/booking/{id}");
		
		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200");
		response.then().spec(responseSpec);
		LOGGER.log(Level.INFO,"HTTP Status Code : "+response.statusCode());

		//To log the response to report
		logResponseAsString(response);
		LOGGER.log(Level.INFO,"Update Operation performed successfully");
		
	}
}
