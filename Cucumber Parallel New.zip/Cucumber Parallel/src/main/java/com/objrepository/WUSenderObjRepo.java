package com.objrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.angular.ngwebdriver.ByAngularButtonText;
import com.angular.ngwebdriver.ByAngularCssContainingText;
import com.angular.ngwebdriver.ByAngularModel;

public class WUSenderObjRepo {

	@ByAngularCssContainingText.FindBy(rootSelector = "a", cssSelector = "li.menuitem:nth-child(6) > a:nth-child(1)", searchText = "Senders")
	public WebElement senders;
	
	//@FindBy(xpath="//*[@ng-click='save(addSenderForm)']")
	@ByAngularCssContainingText.FindBy(rootSelector = "button", cssSelector = "button.btn:nth-child(1)", searchText = "Save")
	public WebElement save;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderName")
	public WebElement senderName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankName")
	public WebElement senderBankName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderAddress")
	public WebElement senderAddress;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankAddress")
	public WebElement senderBankAddress;	
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderZip")
	public WebElement senderZip;	
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankZip")
	public WebElement senderBankZip;	
	
	//@FindBy(xpath="//*[@name='country']//input[2]")
	@FindBy(css = "div[name*='country'] input:nth-of-type(2)")
	public WebElement senderCountrySearch;
	
	//@FindBy(xpath="//*[@name='country']//span[@class='icon gpfi-dropdown glyphicon']")
	@FindBy(css = "div[name*='country'] span[class*='icon gpfi-dropdown glyphicon']")
	public WebElement senderCountrySpan;
	
	//@FindBy(xpath="//*[@name='bankCountry']//input[2]")
	@FindBy(css = "div[name*='bankCountry'] input:nth-of-type(2)")
	public WebElement senderBankCountrySearch;
	
	//@FindBy(xpath="//*[@name='bankCountry']//span[@class='icon gpfi-dropdown glyphicon']")
	@FindBy(css = "div[name*='bankCountry'] span[class*='icon gpfi-dropdown glyphicon']")
	public WebElement senderBankCountrySpan;
	
	//@FindBy(xpath="//*[@class='lead ng-scope tick-msg']/span")
	@FindBy(css = "span[class*='text-success']")
	public WebElement success;
}
