package com.objrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.angular.ngwebdriver.ByAngularButtonText;
import com.angular.ngwebdriver.ByAngularCssContainingText;
import com.angular.ngwebdriver.ByAngularModel;

public class CommonObjRepo {

	@ByAngularModel.FindBy(rootSelector = "input", model = "formCtrl.userName")
	public WebElement userName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "formCtrl.password")
	public WebElement password;
	
	@ByAngularButtonText.FindBy(rootSelector = "button", buttonText = "Login")
	public WebElement loginButton;
	
	@FindBy(css ="#customLinks > li:nth-child(5) > a:nth-child(1)")
	public WebElement logoutBtn;	
	
}
