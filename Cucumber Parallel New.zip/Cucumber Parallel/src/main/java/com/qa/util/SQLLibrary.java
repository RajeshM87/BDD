package com.qa.util;

import  java.sql.Connection;		
import  java.sql.Statement;		
import  java.sql.ResultSet;		
import  java.sql.DriverManager;		
import  java.sql.SQLException;

public class SQLLibrary {

	public static String getOrderStatus(String orderid)
	{
		return "select trsnid from mdm.t_orderinfo where OrderID ='" + orderid + "'";
	}
	
	public static String getPaymentStatus(String orderid)
	{
		return "select pymtnid from mdm.t_paymentinfo where OrderID ='" + orderid + "'";						
	}
}

