package com.qa.util;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ReadJson {

	public static JSONObject readjson(String data) {
		JSONParser parser = new JSONParser();
		
		JSONObject jsonObject = null;
		
		try {
			Object obj = parser.parse(new FileReader(System.getProperty("user.dir") + data));
 
			// A JSON object. Key value pairs are unordered. JSONObject supports java.util.Map interface.
			jsonObject = (JSONObject) obj;	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
}
