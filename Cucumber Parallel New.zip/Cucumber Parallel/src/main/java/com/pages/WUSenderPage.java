package com.pages;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.angular.ngwebdriver.NgWebDriver;
import com.objrepository.WUSenderObjRepo;
import com.qa.util.ConfigReader;
import com.qa.util.ExcelDataAccess;
import com.qa.util.GenericWrappers;
import helper.WaitHelper;
import com.qa.util.ReadJson;

public class WUSenderPage {
	
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	JSONObject jsonObject = null;
	
	GenericWrappers wrappers = new GenericWrappers();
	WUSenderObjRepo senderobjrepo = new WUSenderObjRepo();
	ConfigReader configReader = new ConfigReader();
	
	
	public WUSenderPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, senderobjrepo);
		waitHelper = new WaitHelper(driver);
		//waitHelper.WaitForElement(userName, 60);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);
	}	
	
	public void clickSendersButton() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver,70);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("side-menu")));
		Actions builder = new Actions(driver);
		builder.moveToElement(senderobjrepo.senders).build().perform();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Senders")));
		wrappers.clickByElement(senderobjrepo.senders, driver);
		ngDriver.waitForAngularRequestsToFinish();
	}
	
	public void ProvideTheSenderDetailsUsingJson(){		
				
		jsonObject = ReadJson.readjson("/src/test/resources/testData/TestData.json");
				
		JSONArray senderList = (JSONArray) jsonObject.get("Sender1");
		 
		@SuppressWarnings("unchecked")
		Iterator<JSONObject> iterator = senderList.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
		
		for (Object o : senderList) {
            JSONObject Senders = (JSONObject) o;

            String SenderName = (String) Senders.get("SenderName");
            String StreetAddress = (String) Senders.get("StreetAddress");
            String Country = (String) Senders.get("Country");
            String PostalZip = (String) Senders.get("PostalZip");
            String SenderBankName = (String) Senders.get("SenderBankName");
            String BankStreetAddress = (String) Senders.get("BankStreetAddress");
            String BankPostalZip = (String) Senders.get("BankPostalZip");
            String BankCountry = (String) Senders.get("BankCountry");                  
           
          /*  JSONArray arrays = (JSONArray) Senders.get("cars");
            for (Object object : arrays) {
                System.out.println("cars::::" + object);
            }*/
            
            WebDriverWait wait = new WebDriverWait(driver,80);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
            wrappers.enterByElement(senderobjrepo.senderName, SenderName, driver);
            wrappers.enterByElement(senderobjrepo.senderBankName, SenderBankName, driver);
            wrappers.enterByElement(senderobjrepo.senderAddress, StreetAddress, driver);
            wrappers.enterByElement(senderobjrepo.senderBankAddress, BankStreetAddress, driver);
            wrappers.enterByElement(senderobjrepo.senderZip, PostalZip, driver);
            senderobjrepo.senderZip.sendKeys(Keys.TAB);
            wrappers.enterByElement(senderobjrepo.senderCountrySearch, Country, driver);
            wrappers.enterByElement(senderobjrepo.senderBankZip, BankPostalZip, driver);
            senderobjrepo.senderBankZip.sendKeys(Keys.TAB);
            wrappers.enterByElement(senderobjrepo.senderBankCountrySearch, BankCountry, driver); 
        	            
		}
        	
	}
	
	public void ProvideTheSenderDetailsUsingExcel(){	
		
		String SenderName = null;
		String StreetAddress= null;
		String Country= null;
		String PostalZip= null;
		String SenderBankName= null;
		String BankStreetAddress= null;
		String BankPostalZip= null;
		String BankCountry= null;
		
		ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", "TestData");			
		testdata.setDatasheetName("TestData");
		
		int nTestInstances = testdata.getLastRowNum();
		
		for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
			
			SenderName = testdata.getValue(currentTestInstance, "SenderName");
			StreetAddress = testdata.getValue(currentTestInstance, "StreetAddress");
			Country = testdata.getValue(currentTestInstance, "Country");
			PostalZip = testdata.getValue(currentTestInstance, "PostalZip");
			SenderBankName = testdata.getValue(currentTestInstance, "SenderBankName");
			BankStreetAddress = testdata.getValue(currentTestInstance, "BankStreetAddress");
			BankPostalZip = testdata.getValue(currentTestInstance, "BankPostalZip");
			BankCountry = testdata.getValue(currentTestInstance, "BankCountry");
			
		}
	        
        WebDriverWait wait = new WebDriverWait(driver,80);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
        wrappers.enterByElement(senderobjrepo.senderName, SenderName, driver);
        wrappers.enterByElement(senderobjrepo.senderBankName, SenderBankName, driver);
        wrappers.enterByElement(senderobjrepo.senderAddress, StreetAddress, driver);
        wrappers.enterByElement(senderobjrepo.senderBankAddress, BankStreetAddress, driver);
        wrappers.enterByElement(senderobjrepo.senderZip, PostalZip, driver);
        senderobjrepo.senderZip.sendKeys(Keys.TAB);
        wrappers.enterByElement(senderobjrepo.senderCountrySearch, Country, driver);
        wrappers.enterByElement(senderobjrepo.senderBankZip, BankPostalZip, driver);
        senderobjrepo.senderBankZip.sendKeys(Keys.TAB);
        wrappers.enterByElement(senderobjrepo.senderBankCountrySearch, BankCountry, driver);        
      
	}

	public void SaveAndVerifyTheSenderDetails(){
		senderobjrepo.save.isEnabled();
		senderobjrepo.save.click();
		senderobjrepo.save.click();
		
       	 assertThat(senderobjrepo.success.getText(), containsString("Success"));
	}
	
/*	public void clickLogoutButton(){
		Actions builder = new Actions(driver);
		builder.moveToElement(SignInfromNav).build().perform();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", logoutBtn);;
	}*/
}
