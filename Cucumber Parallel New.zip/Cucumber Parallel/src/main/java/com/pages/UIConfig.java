package com.pages;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.angular.ngwebdriver.NgWebDriver;
import com.objrepository.CommonObjRepo;
import com.objrepository.WUSenderObjRepo;
import com.qa.util.ConfigReader;
import com.qa.util.GenericWrappers;
import helper.WaitHelper;
import helper.Constants;

public class UIConfig {
	
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	JSONObject jsonObject = null;
		
	GenericWrappers wrappers = new GenericWrappers();
	ConfigReader configReader = new ConfigReader();
	WUSenderObjRepo senderobjrepo = new WUSenderObjRepo();
	CommonObjRepo commonobjrepo = new CommonObjRepo();
	
	
	public UIConfig(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, commonobjrepo);
		waitHelper = new WaitHelper(driver);
		//waitHelper.WaitForElement(userName, 60);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);
	}
	
	public void launchapp() throws InterruptedException{
		Properties prop;
		//prop = configReader.init_prop("config.properties");
		String environment = System.getenv("env");
		System.out.println("Environment value:" + environment);
		if(environment.equals("uat"))
		{
			prop = configReader.init_prop("uat.properties");
		}
		else
		{
			prop = configReader.init_prop("acp.properties");
		}
	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(prop.getProperty("appurl"));
		driver.manage().window().maximize();
		ngDriver.waitForAngularRequestsToFinish();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("j_username")));
				
	}
	
	public void userNameDisplay(){
		commonobjrepo.userName.isDisplayed();
	}
	
	public void enterUserName() throws InterruptedException{			
		//this.userName.sendKeys(Constants.getUsername());
		wrappers.enterByElement(commonobjrepo.userName, Constants.getUsername(), driver);
	}
	
	public void enterPassword(){
		//this.password.sendKeys(Constants.getPassword());
		wrappers.enterByElement(commonobjrepo.password, Constants.getPassword(), driver);
	}
	
	public void clickLoginButton(){
		wrappers.clickByElement(commonobjrepo.loginButton, driver);
		ngDriver.waitForAngularRequestsToFinish();
	}	
		
/*	public void clickLogoutButton(){
		Actions builder = new Actions(driver);
		builder.moveToElement(SignInfromNav).build().perform();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", logoutBtn);;
	}*/
}
