package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import com.pages.UIConfig;
import com.qa.factory.DriverFactory;

public class UIConfigStepDefinitions  {

	UIConfig uiconfig;	
	
	public UIConfigStepDefinitions(){
		uiconfig = new UIConfig(DriverFactory.getDriver());		
	}
	
	  @Given("^I am on the Login page URL$") 
	  public void i_am_on_the_Login_page_URL() throws Throwable { 
		  uiconfig.launchapp();	  
	  }
	  
	  @When("^I should see Sign In Page$")
	  public void i_should_see_Sign_In_Page() throws Throwable { 
		  uiconfig.userNameDisplay(); 
	  }
	  
	  @And("^I enter username$") 
	  public void i_enter_username() throws Throwable {
	  uiconfig.enterUserName(); 
	  }
	  
	  @And("^I enter password$") 
	  public void i_enter_password() throws Throwable {
	  uiconfig.enterPassword(); 
	  }
	  
	  @And("^click on login button$") 
	  public void click_on_login_button() throws Throwable { 
	  uiconfig.clickLoginButton(); 
	  }	
	
	/*	@When("^I Click on Sign out$")
	public void i_Click_on_Sign_out() throws Throwable {
	    senderPage.clickLogoutButton();
	    waitHelper.WaitForElement(senderPage.userName, 60);
	}*/
	
}