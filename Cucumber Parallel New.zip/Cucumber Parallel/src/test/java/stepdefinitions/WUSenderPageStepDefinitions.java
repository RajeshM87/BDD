package stepdefinitions;

import helper.WaitHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import com.pages.WUSenderPage;
import com.qa.factory.DriverFactory;

public class WUSenderPageStepDefinitions  {

	WUSenderPage senderPage;
	WaitHelper waitHelper;
	
	public WUSenderPageStepDefinitions(){
		senderPage = new WUSenderPage(DriverFactory.getDriver());
		waitHelper = new WaitHelper(DriverFactory.getDriver());	
	}

	@Given("^I clicked on senders button$")
	public void i_clicked_on_senders_button() throws Throwable {
		senderPage.clickSendersButton();
	}
	
	@When("^Provide the sender details using json$")
	public void provide_the_sender_details_using_json() throws Throwable {
	    senderPage.ProvideTheSenderDetailsUsingJson();
	}
	
	@When("^Provide the sender details using excel$")
	public void provide_the_sender_details_using_excel() throws Throwable {
	    senderPage.ProvideTheSenderDetailsUsingExcel();
	}
	
	@Then("^Save and verify the sender details$")
	public void Save_and_verify_the_sender_details() throws Throwable {
	    senderPage.SaveAndVerifyTheSenderDetails();
	}	
}