$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/java/features/wusender.feature");
formatter.feature({
  "name": "As a Western Money user I should be able to login and logout with valid credentials",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@WUDEMO"
    }
  ]
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: unable to discover open pages\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 75.35 seconds\nBuild info: version: \u00273.7.1\u0027, revision: \u00278a0099a\u0027, time: \u00272017-11-06T21:01:39.354Z\u0027\nSystem info: host: \u0027RAJESHSINDHU\u0027, ip: \u0027192.168.1.8\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_112\u0027\nDriver info: driver.version: ChromeDriver\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$new$0(JsonWireProtocolResponse.java:53)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$getResponseFunction$2(JsonWireProtocolResponse.java:91)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:123)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:193)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Spliterators.java:958)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(ReferencePipeline.java:126)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(AbstractPipeline.java:498)\r\n\tat java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:485)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:471)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(FindOps.java:152)\r\n\tat java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)\r\n\tat java.util.stream.ReferencePipeline.findFirst(ReferencePipeline.java:464)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:126)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:73)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:142)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:600)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:219)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:142)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat testBase.TestBase.selectBrowser(TestBase.java:20)\r\n\tat stepdefinitions.ServiceHooks.initializeTest(ServiceHooks.java:41)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "I am on the Login page URL",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_am_on_the_Login_page_URL()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "I should see Sign In Page",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_should_see_Sign_In_Page()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "I enter username",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_enter_username()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "I enter password",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_enter_password()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "click on login button",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.click_on_login_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.scenario({
  "name": "Create A Sender with valid test data using excel",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@WUDEMO"
    }
  ]
});
formatter.step({
  "name": "I clicked on senders button",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_clicked_on_senders_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "Provide the sender details using excel",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.provide_the_sender_details_using_excel()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.step({
  "name": "Save and verify the sender details",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.Save_and_verify_the_sender_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.afterstep({
  "status": "skipped"
});
formatter.after({
  "error_message": "java.lang.NullPointerException\r\n\tat stepdefinitions.ServiceHooks.endTest(ServiceHooks.java:100)\r\n",
  "status": "failed"
});
formatter.background({
  "name": "",
  "description": "",
  "keyword": "Background"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "I am on the Login page URL",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_am_on_the_Login_page_URL()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded0.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "I should see Sign In Page",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_should_see_Sign_In_Page()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded1.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "I enter username",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_enter_username()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded2.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "I enter password",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_enter_password()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded3.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "click on login button",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.click_on_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded4.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.scenario({
  "name": "Create A Sender with valid test data using json",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@WUDEMO"
    }
  ]
});
formatter.step({
  "name": "I clicked on senders button",
  "keyword": "Given "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.i_clicked_on_senders_button()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded5.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Provide the sender details using json",
  "keyword": "When "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.provide_the_sender_details_using_json()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded6.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.step({
  "name": "Save and verify the sender details",
  "keyword": "Then "
});
formatter.match({
  "location": "stepdefinitions.WUSenderPageStepDefinitions.Save_and_verify_the_sender_details()"
});
formatter.result({
  "status": "passed"
});
formatter.embedding("image/png", "embedded7.png", null);
formatter.afterstep({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});