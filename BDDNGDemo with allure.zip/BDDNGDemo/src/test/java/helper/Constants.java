package helper;


public class Constants {


	public final static String userName = "ParentMember";
	public final static String password = "Password12";
	
	public final static long explicitWait = 10000;
	public final static long impliciteWait = 10000;
	
	public static String getUsername() {
		return userName;
	}
	public static String getPassword() {
		return password;
	}
	public static long getExplicitwait() {
		return explicitWait;
	}
	public static long getImplicitewait() {
		return impliciteWait;
	}
	
}
