package runner; 	

import org.junit.runner.RunWith;
import org.testng.annotations.DataProvider;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/java/features" }, 
plugin = { "pretty", "html:test-output","io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm",	"html:target/cucumber-html-reports", 
        "json:target/cucumber-reports/cucumber.json", "junit:target/cucumber-reports/cucumber.xml", "rerun:target/failed_scenarios.txt" }, monochrome = true, glue = { "stepdefinitions" }, tags = {"@WUDEMO"})

public class RunParallelIT extends AbstractTestNGCucumberTests {

      @Override
      @DataProvider(parallel = true)	
      public Object[][] scenarios() {
            return super.scenarios();
      }
}
	 

