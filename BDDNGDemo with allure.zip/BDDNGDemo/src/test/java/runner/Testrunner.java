package runner; 	

import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/java/features" }, 
plugin = { "pretty", "html:test-output","io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm",	"html:target/cucumber-html-reports", 
        "json:target/cucumber-reports/cucumber.json", "junit:target/cucumber-reports/cucumber.xml", "rerun:target/failed_scenarios.txt" }, monochrome = true, glue = { "stepdefinitions" }, tags = {"@WUDEMO"})

public class Testrunner {
	
}

	 

