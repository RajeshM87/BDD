package enums;

public enum OS {
	
	WINDOW,
	MAC

}
