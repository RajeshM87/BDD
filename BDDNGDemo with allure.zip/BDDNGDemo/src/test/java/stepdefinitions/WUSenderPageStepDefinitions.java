package stepdefinitions;

import org.openqa.selenium.WebDriver;

import helper.WaitHelper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.WUSenderPage;
import testBase.TestBase;


public class WUSenderPageStepDefinitions  {

	WUSenderPage senderPage;
	WaitHelper waitHelper;
	private WebDriver driver;
	

	@Given("^I am on the Login page URL$")
	public void i_am_on_the_Login_page_URL() throws Throwable {
		senderPage = new WUSenderPage(TestBase.driver);
		waitHelper = new WaitHelper(TestBase.driver);	
		senderPage.launchapp();
		
	}
	@When("^I should see Sign In Page$")
	public void i_should_see_Sign_In_Page() throws Throwable {
		senderPage.userName.isDisplayed();
	}

	@And("^I enter username$")
	public void i_enter_username() throws Throwable {
		senderPage.enterUserName();
	}

	@And("^I enter password$")
	public void i_enter_password() throws Throwable {
		senderPage.enterPassword();
	}

	@And("^click on login button$")
	public void click_on_login_button() throws Throwable {
		senderPage.clickLoginButton();
	}
	
	@Given("^I clicked on senders button$")
	public void i_clicked_on_senders_button() throws Throwable {
		senderPage.clickSendersButton();
	}
	
	@When("^Provide the sender details using json$")
	public void provide_the_sender_details_using_json() throws Throwable {
	    senderPage.ProvideTheSenderDetailsUsingJson();
	}
	
	@When("^Provide the sender details using excel$")
	public void provide_the_sender_details_using_excel() throws Throwable {
	    senderPage.ProvideTheSenderDetailsUsingExcel();
	}
	
	@Then("^Save and verify the sender details$")
	public void Save_and_verify_the_sender_details() throws Throwable {
	    senderPage.SaveAndVerifyTheSenderDetails();
	}
	
	/*	@When("^I Click on Sign out$")
	public void i_Click_on_Sign_out() throws Throwable {
	    senderPage.clickLogoutButton();
	    waitHelper.WaitForElement(senderPage.userName, 60);
	}*/

	
}