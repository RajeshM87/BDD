package stepdefinitions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.AfterClass;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.angular.ngwebdriver.NgWebDriver;

import enums.Browsers;
import helper.LoggerHelper;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;
import net.masterthought.cucumber.sorting.SortingMethod;
import testBase.SharedDriver;
import testBase.TestBase;


public class ServiceHooks {

	TestBase testBase;
	public static NgWebDriver ngDriver;

	Logger log = LoggerHelper.getLogger(ServiceHooks.class);

	@Before
	public void initializeTest() {
		testBase = new TestBase();
		testBase.selectBrowser(Browsers.CHROME.name());
		ngDriver = new NgWebDriver((JavascriptExecutor)TestBase.driver);
		ngDriver.waitForAngularRequestsToFinish();
	}

	@AfterStep 
	public void endStep(Scenario scenario) {
		if (scenario.isFailed()) {

			try {
				log.info(scenario.getName() + " is Failed");
				final byte[] screenshot = ((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.BYTES);
				scenario.embed(screenshot, "image/png"); // ... and embed it in
			} catch (WebDriverException e) {
				e.printStackTrace();
			}

		} else {
			try {
				log.info(scenario.getName() + " is pass");
				scenario.embed(((TakesScreenshot) TestBase.driver).getScreenshotAs(OutputType.BYTES), "image/png");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
	}
	
	/*@AfterClass
	public void endClass() {
		
	    File reportOutputDirectory = new File("target/cucumber-reports");
	    List<String> jsonFiles = new ArrayList<String>();
	    jsonFiles.add("./target/cucumber-reports/cucumber.json");

	    String buildNumber = "1";
	    String projectName = "WU";
	    boolean runWithJenkins = false;
	    boolean parallelTesting = false;

	    Configuration configuration = new Configuration(reportOutputDirectory, projectName);

	    // optional configuration
	    configuration.setParallelTesting(parallelTesting);
	    configuration.setRunWithJenkins(runWithJenkins);
	    configuration.setBuildNumber(buildNumber);
	    configuration.setSortingMethod(SortingMethod.NATURAL);
	  	configuration.setTrendsStatsFile(new File("target/test-classes/demo.json"));
	    // addidtional metadata presented on main page
	    configuration.addClassifications("Platform","Windows");
	    configuration.addClassifications("Browser","chrome");
	    configuration.addClassifications("Branch","release/1.0");

	    ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
	    reportBuilder.generateReports();

}*/
	
	@After
	public void endTest() {
		TestBase.driver.quit();		

	}
}
