package pageObjects;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.Annotations;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.angular.ngwebdriver.NgWebDriver;
import com.google.common.base.Function;
import com.angular.ngwebdriver.ByAngular;

import com.angular.ngwebdriver.ByAngularBinding;
import com.angular.ngwebdriver.ByAngularButtonText;
import com.angular.ngwebdriver.ByAngularCssContainingText;
import com.angular.ngwebdriver.ByAngularExactBinding;
import com.angular.ngwebdriver.ByAngularModel;
import com.angular.ngwebdriver.ByAngularOptions;
import com.angular.ngwebdriver.ByAngularPartialButtonText;
import com.angular.ngwebdriver.ByAngularRepeater;
import com.angular.ngwebdriver.ByAngularRepeaterCell;
import com.angular.ngwebdriver.ByAngularRepeaterColumn;
import com.angular.ngwebdriver.ByAngularRepeaterRow;

import helper.WaitHelper;
import util.ReadJson;
import helper.Constants;
import util.GenericWrappers;
import util.ExcelDataAccess;

public class WUSenderPage {
	
	private WebDriver driver;
	GenericWrappers wrappers = new GenericWrappers();
	JSONObject jsonObject = null;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "formCtrl.userName")
	public WebElement userName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "formCtrl.password")
	public WebElement password;
	
	@ByAngularButtonText.FindBy(rootSelector = "button", buttonText = "Login")
	public WebElement loginButton;
	
	@FindBy(css ="#customLinks > li:nth-child(5) > a:nth-child(1)")
	public WebElement logoutBtn;
	
	@ByAngularCssContainingText.FindBy(rootSelector = "a", cssSelector = "li.menuitem:nth-child(6) > a:nth-child(1)", searchText = "Senders")
	public WebElement senders;
	
	//@FindBy(xpath="//*[@ng-click='save(addSenderForm)']")
	@ByAngularCssContainingText.FindBy(rootSelector = "button", cssSelector = "button.btn:nth-child(1)", searchText = "Save")
	public WebElement save;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderName")
	public WebElement senderName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankName")
	public WebElement senderBankName;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderAddress")
	public WebElement senderAddress;
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankAddress")
	public WebElement senderBankAddress;	
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderZip")
	public WebElement senderZip;	
	
	@ByAngularModel.FindBy(rootSelector = "input", model = "state.senderBankZip")
	public WebElement senderBankZip;	
	
	//@FindBy(xpath="//*[@name='country']//input[2]")
	@FindBy(css = "div[name*='country'] input:nth-of-type(2)")
	public WebElement senderCountrySearch;
	
	//@FindBy(xpath="//*[@name='country']//span[@class='icon gpfi-dropdown glyphicon']")
	@FindBy(css = "div[name*='country'] span[class*='icon gpfi-dropdown glyphicon']")
	public WebElement senderCountrySpan;
	
	//@FindBy(xpath="//*[@name='bankCountry']//input[2]")
	@FindBy(css = "div[name*='bankCountry'] input:nth-of-type(2)")
	public WebElement senderBankCountrySearch;
	
	//@FindBy(xpath="//*[@name='bankCountry']//span[@class='icon gpfi-dropdown glyphicon']")
	@FindBy(css = "div[name*='bankCountry'] span[class*='icon gpfi-dropdown glyphicon']")
	public WebElement senderBankCountrySpan;
	
	//@FindBy(xpath="//*[@class='lead ng-scope tick-msg']/span")
	@FindBy(css = "span[class*='text-success']")
	public WebElement success;
	
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
		
	public WUSenderPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
		//waitHelper.WaitForElement(userName, 60);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);
	}
	
	public void launchapp() throws InterruptedException{
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://uat.gpfi.globalpay.westernunion.com/geo/#/");
		driver.manage().window().maximize();
		ngDriver.waitForAngularRequestsToFinish();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);  
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("j_username")));
				
	}
	public void enterUserName() throws InterruptedException{			
		//this.userName.sendKeys(Constants.getUsername());
		wrappers.enterByElement(userName, Constants.getUsername(), driver);
	}
	
	public void enterPassword(){
		//this.password.sendKeys(Constants.getPassword());
		wrappers.enterByElement(password, Constants.getPassword(), driver);
	}
	
	public void clickLoginButton(){
		//this.loginButton.click();
		wrappers.clickByElement(loginButton, driver);
		ngDriver.waitForAngularRequestsToFinish();
	}
	
	public void clickSendersButton() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver,50);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("side-menu")));
		Actions builder = new Actions(driver);
		builder.moveToElement(senders).build().perform();
		wrappers.clickByElement(senders, driver);
		ngDriver.waitForAngularRequestsToFinish();
	}
	
	public void ProvideTheSenderDetailsUsingJson(){		
				
		jsonObject = ReadJson.readjson("/resources/testData/TestData.json");
				
		JSONArray senderList = (JSONArray) jsonObject.get("Sender1");
		 
		@SuppressWarnings("unchecked")
		Iterator<JSONObject> iterator = senderList.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
		
		for (Object o : senderList) {
            JSONObject Senders = (JSONObject) o;

            String SenderName = (String) Senders.get("SenderName");
            System.out.println("SenderName::::" + SenderName);

            String StreetAddress = (String) Senders.get("StreetAddress");
            System.out.println("StreetAddress::::" + StreetAddress);
            
            String Country = (String) Senders.get("Country");
            System.out.println("Country::::" + Country);
            
            String PostalZip = (String) Senders.get("PostalZip");
            System.out.println("PostalZip::::" + PostalZip);
            
            String SenderBankName = (String) Senders.get("SenderBankName");
            System.out.println("SenderBankName::::" + SenderBankName);
            
            String BankStreetAddress = (String) Senders.get("BankStreetAddress");
            System.out.println("BankStreetAddress1::::" + BankStreetAddress);
            
            String BankPostalZip = (String) Senders.get("BankPostalZip");
            System.out.println("BankPostalZip::::" + BankPostalZip);
            
            String BankCountry = (String) Senders.get("BankCountry");
            System.out.println("BankCountry::::" + BankCountry);
            
           
          /*  JSONArray arrays = (JSONArray) Senders.get("cars");
            for (Object object : arrays) {
                System.out.println("cars::::" + object);
            }*/
            
            WebDriverWait wait = new WebDriverWait(driver,30);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
            wrappers.enterByElement(senderName, SenderName, driver);
            wrappers.enterByElement(senderBankName, SenderBankName, driver);
            wrappers.enterByElement(senderAddress, StreetAddress, driver);
            wrappers.enterByElement(senderBankAddress, BankStreetAddress, driver);
            wrappers.enterByElement(senderZip, PostalZip, driver);
            this.senderZip.sendKeys(Keys.TAB);
            wrappers.enterByElement(senderCountrySearch, Country, driver);
            wrappers.enterByElement(senderBankZip, BankPostalZip, driver);
            this.senderBankZip.sendKeys(Keys.TAB);
            wrappers.enterByElement(senderBankCountrySearch, BankCountry, driver); 
        	            
		}
        	
	}
	
	public void ProvideTheSenderDetailsUsingExcel(){	
		
		String SenderName = null;
		String StreetAddress= null;
		String Country= null;
		String PostalZip= null;
		String SenderBankName= null;
		String BankStreetAddress= null;
		String BankPostalZip= null;
		String BankCountry= null;
		
		ExcelDataAccess testdata = new ExcelDataAccess("./resources/testData/", "TestData");			
		testdata.setDatasheetName("TestData");
		
		int nTestInstances = testdata.getLastRowNum();
		
		for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
			
			SenderName = testdata.getValue(currentTestInstance, "SenderName");
			StreetAddress = testdata.getValue(currentTestInstance, "StreetAddress");
			Country = testdata.getValue(currentTestInstance, "Country");
			PostalZip = testdata.getValue(currentTestInstance, "PostalZip");
			SenderBankName = testdata.getValue(currentTestInstance, "SenderBankName");
			BankStreetAddress = testdata.getValue(currentTestInstance, "BankStreetAddress");
			BankPostalZip = testdata.getValue(currentTestInstance, "BankPostalZip");
			BankCountry = testdata.getValue(currentTestInstance, "BankCountry");
			
		}
	        
        WebDriverWait wait = new WebDriverWait(driver,40);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
        wrappers.enterByElement(senderName, SenderName, driver);
        wrappers.enterByElement(senderBankName, SenderBankName, driver);
        wrappers.enterByElement(senderAddress, StreetAddress, driver);
        wrappers.enterByElement(senderBankAddress, BankStreetAddress, driver);
        wrappers.enterByElement(senderZip, PostalZip, driver);
        this.senderZip.sendKeys(Keys.TAB);
        wrappers.enterByElement(senderCountrySearch, Country, driver);
        wrappers.enterByElement(senderBankZip, BankPostalZip, driver);
        this.senderBankZip.sendKeys(Keys.TAB);
        wrappers.enterByElement(senderBankCountrySearch, BankCountry, driver);        
      
	}

	public void SaveAndVerifyTheSenderDetails(){
		 this.save.isEnabled();
         this.save.click();
         this.save.click();
		
       	 assertThat(this.success.getText(), containsString("Success"));
	}
	
/*	public void clickLogoutButton(){
		Actions builder = new Actions(driver);
		builder.moveToElement(SignInfromNav).build().perform();
		JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("arguments[0].click();", logoutBtn);;
	}*/
}
