package testBase;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import enums.Browsers;
import enums.OS;

public class SharedDriver extends EventFiringWebDriver {
    public static WebDriver REAL_DRIVER = null;



    private static final Thread CLOSE_THREAD = new Thread() {
        @Override
        public void run() {
            REAL_DRIVER.close();
        }
    };

    static {
        Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
    }

    public SharedDriver() {
        super(CreateDriver());
    }

    public static WebDriver CreateDriver() {
        WebDriver webDriver = null;
        if (REAL_DRIVER == null)
            webDriver = new ChromeDriver();
        setWebDriver(webDriver);
        return webDriver;
    }

    public static void setWebDriver(WebDriver webDriver) {
        REAL_DRIVER = webDriver;
    }

    public static WebDriver getWebDriver() {
        return REAL_DRIVER;
    }

    @Override
    public void close() {
        if (Thread.currentThread() != CLOSE_THREAD) {
            throw new UnsupportedOperationException("You shouldn't close this WebDriver. It's shared and will close when the JVM exits.");
        }
        super.close();
    }

    public static WebDriver selectBrowser(String browser) {
		if (System.getProperty("os.name").toLowerCase().contains(OS.WINDOW.name().toLowerCase())) {
			if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/resources/drivers/chromedriver.exe");
				
				REAL_DRIVER = new ChromeDriver();
				REAL_DRIVER.manage().deleteAllCookies();
				REAL_DRIVER.manage().window().maximize();
			} else if (browser.equalsIgnoreCase(Browsers.FIREFOX.name())) {
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/resources/drivers/geckodriver.exe");
				REAL_DRIVER = new FirefoxDriver();
				REAL_DRIVER.manage().deleteAllCookies();
				REAL_DRIVER.manage().window().maximize();
			}
		} else if (System.getProperty("os.name").toLowerCase().contains(OS.MAC.name().toLowerCase())) {
			if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/resources/drivers/chromedriver");
				REAL_DRIVER = new ChromeDriver();
				REAL_DRIVER.manage().deleteAllCookies();
				REAL_DRIVER.manage().window().maximize();
			} else if (browser.equalsIgnoreCase(Browsers.FIREFOX.name())) {
				System.setProperty("webdriver.firefox.marionette", System.getProperty("user.dir") + "/resources/drivers/geckodriver");
				REAL_DRIVER = new FirefoxDriver();
				REAL_DRIVER.manage().deleteAllCookies();
				REAL_DRIVER.manage().window().maximize();
			}
		}
		return REAL_DRIVER;
	}
  /*  @Before
    public void deleteAllCookies() {
        manage().deleteAllCookies();
    }

    @After
    public void embedScreenshot(Scenario scenario) {
        try {
            byte[] screenshot = getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
        }
    }*/
}