Pre-requisite:
1.	Install Java, Maven and Intellij
2.	Setup environment variables for all the required software’s path(Java, Maven, Allure)

Framework Details:
1. Object repository for each web page is available under com.objrepository package
2. All the main flow of the scripts foe each page is available under com.pages package
3. Driver setup with different browsers and grid is available under com.qa.factory package
4. Reusable and common methods which is used in the scripts are available under com.qa.util package
5. Wait and logger methods are available under helper package
6. Before and After annotation hooks and all the page step definitions are available under stepdefinitions page
7. TestNG runner and Parallel runner is available under testrunners package 
8. All the browser and environment configurations and feature files of each web page and Test data with excel and json  
for input to the scripts and reports properties are available under resources folder 
9. Reports and Screenshots will be available under target folder.


Steps to setup framework in Intellij: 
1. Launch IntelliJ IDEA.
2. If the Welcome screen opens, click Open.
   Otherwise, from the main menu, select File | Open.
3. In the dialog that opens, select the directory in which your sources, libraries, and other assets are located
   and click Open.
4. When you import or clone a project for the first time, IntelliJ IDEA analyzes it.
   If the IDE detects more than one configuration (for example, Eclipse and Gradle), it prompts you to select which
   configuration you want to use.
   If the project that you are importing uses a build tool, such as Maven or Gradle, we recommend that you
   select the build tool configuration.
5. Select the necessary configuration and click OK.
6. Dialog that prompts you to select how you want to import the project
7. The IDE pre-configures the project according to your choice. For example, if you select Maven, IntelliJ IDEA
   executes its build scripts, loads dependencies, and so on.
8. If you have been working with another project, select whether you want to open the new project in a new dialog
   or in the current one.