package stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.qa.factory.DriverFactory;
import com.qa.util.ConfigReader;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class ApplicationHooks {

	private DriverFactory driverFactory;
	private WebDriver driver;
	private ConfigReader configReader;
	Properties prop;
	private final static Logger LOGGER = 
            Logger.getLogger(ApplicationHooks.class);

	
	@Before(order = 0) 
	public void getProperty() { 
		 configReader = new ConfigReader(); 
		 prop = configReader.init_prop("config.properties"); 
	}	 

	@Before(order = 1)
	//@Before
	public void launchBrowser() {
		String browserName = prop.getProperty("browser");
		//String browserName = System.getenv("browser");
		driverFactory = new DriverFactory();
		this.driver = driverFactory.init_driver(browserName);
		
	}

	@AfterStep
	public void endStep(Scenario scenario) {
		if (scenario.isFailed()) {

			try {
				LOGGER.info(scenario.getName() + " is Failed");
				final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				scenario.attach(screenshot, "image/png", "Scenario Failed"); // ... and embed it in
			} catch (WebDriverException e) {
				e.printStackTrace();
			}

		} else {
			try {
				LOGGER.info(scenario.getName() + " is Passed");
				scenario.attach(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES), "image/png", "Scenario Passed");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@After(order = 0)
	public void quitBrowser() {
		driver.quit();		

	}

	public static String capture(WebDriver driver) throws IOException {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Dest = new File("target/cucumber-reports/Screenshots/failedsnap_" + System.currentTimeMillis() + ".png");
		String errflpath = Dest.getAbsolutePath();
		FileUtils.copyFile(scrFile, Dest);
		return errflpath;
	}

	/*
	 * @After(order = 1) public void tearDown(Scenario scenario) { if
	 * (scenario.isFailed()) { // take screenshot: String screenshotName =
	 * scenario.getName().replaceAll(" ", "_"); byte[] sourcePath =
	 * ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	 * scenario.attach(sourcePath, "image/png", screenshotName);
	 * 
	 * } }
	 */

}
