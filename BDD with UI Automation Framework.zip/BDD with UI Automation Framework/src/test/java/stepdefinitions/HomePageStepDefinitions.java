package stepdefinitions;

import helper.WaitHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import com.pages.HomePage;
import com.qa.factory.DriverFactory;

public class HomePageStepDefinitions  {

	HomePage homepagestepdef;
	WaitHelper waitHelper;
	
	public HomePageStepDefinitions(){
		homepagestepdef = new HomePage(DriverFactory.getDriver());
		waitHelper = new WaitHelper(DriverFactory.getDriver());	
	}	
	
	@Given("^I clicked on AddToCart button$")
	public void click_On_AddToCart() throws Throwable {
		homepagestepdef.clickOnAddToCart();
	}

	@When("^I clicked on ShoppingCart icon$")
	public void click_On_ShoppingCart() throws Throwable {
		homepagestepdef.clickOnShoppingCart();
	}	
			
}