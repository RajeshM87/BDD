package testrunners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"@target/rerun.txt"}, glue = {"stepdefinitions", "ApplicationHooks"},	plugin = {"pretty",
		"timeline:target/test-output-thread/"}
		,monochrome = true)

public class FailedTestRunner extends AbstractTestNGCucumberTests{

}
