package com.qa.factory;

import java.net.MalformedURLException;
import java.net.URL;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {

	public WebDriver driver;
	String seleniumHub = "192.168.43.223";
	String seleniumHubPort = "5566";

	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

	/**
	 * This method is used to initialize the thread local driver on the basis of given
	 * browser
	 * 
	 * @param browser
	 * @return this will return tldriver.
	 */
	
	public WebDriver init_driver(String browser) {

		LOGGER.log(Level.INFO, "Browser value is: " + browser);
		
		if (browser.equals("chrome")) {
			
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--ignore-certificate-errors");
			options.setAcceptInsecureCerts(true);			
			 			 			
			WebDriverManager.chromedriver().setup();
			tlDriver.set(new ChromeDriver(options));
		} else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			tlDriver.set(new FirefoxDriver());
		} else if (browser.equals("grid")) {
			DesiredCapabilities capability = DesiredCapabilities.chrome();
	        capability.setBrowserName("chrome");
	        capability.setPlatform(Platform.WIN10);
			WebDriverManager.seleniumServerStandalone().setup();
			URL remote_grid = null;
			try {
				remote_grid = new URL("http://" + seleniumHub + ":" + seleniumHubPort + "/wd/hub");
				driver = new RemoteWebDriver(remote_grid, capability);
			} catch (MalformedURLException e) {				
				e.getMessage();
			}			
		}
		else {
			LOGGER.log(Level.INFO, "Please pass the correct browser value: " + browser);			
		}
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();
	}

	/**
	 * this is used to get the driver with ThreadLocal
	 * 
	 * @return
	 */
	public static synchronized WebDriver getDriver() {
		return tlDriver.get();
	}
}
