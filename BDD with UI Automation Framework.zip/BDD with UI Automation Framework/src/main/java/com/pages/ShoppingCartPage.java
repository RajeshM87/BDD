package com.pages;

import java.io.ByteArrayInputStream;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.objrepository.ShoppingCartPageObjRepo;

import java.util.logging.Level;
import java.util.logging.Logger;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.qa.util.GenericWrappers;

import helper.WaitHelper;
import io.qameta.allure.Allure;
import com.qa.util.FrameworkException;

public class ShoppingCartPage extends GenericWrappers {
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	
	public ShoppingCartPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);		
	}
	
	UIConfig uiconfig = new UIConfig(driver);
	public Properties properties = uiconfig.getenvproperties();
		
	// Method to click on 'CheckOut' button
		public void clickOnCheckOut() {
			try {	
				WebElement checkout = driver.findElement(ShoppingCartPageObjRepo.checkout);
				clickByElement(checkout, driver);
				LOGGER.log(Level.INFO, "Clicked on CheckOut button successfully");						
				Allure.addAttachment("Clicked on CheckOut button successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
				 
			} catch (Exception e) {				
				throw new FrameworkException("ShoppingCart Page", "Error in clicking on 'CheckOut' button in ShoppingCart page");
				//e.fillInStackTrace();
			}
		}	
}
