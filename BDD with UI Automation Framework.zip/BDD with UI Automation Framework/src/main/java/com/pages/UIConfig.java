package com.pages;

import java.io.ByteArrayInputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.objrepository.CommonObjRepo;
import com.qa.util.ConfigReader;
import com.qa.util.ExcelDataAccess;
import com.qa.util.GenericWrappers;
import helper.WaitHelper;
import io.qameta.allure.Allure;
import helper.Constants;
import com.qa.util.ReadJson;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UIConfig extends GenericWrappers{
	
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	JSONObject jsonObject = null;
	public Properties properties = null; 
	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
		
	ConfigReader configReader = new ConfigReader();
		
	public UIConfig(WebDriver driver){
		super(driver);
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);
	}
	
	public Properties getenvproperties() { 	  		 
		  //String environment = System.getenv("env"); 
		  properties = configReader.init_prop("config.properties"); 
		  String environment = properties.getProperty("env");
		  LOGGER.log(Level.INFO, "Environment value:" + environment);
		  
		  if(environment.equals("uat")) { 
			  properties = configReader.init_prop("uat.properties");	
			  LOGGER.log(Level.INFO, "Environment value set as: UAT");
		  } else if(environment.equals("acp")) { 
			  properties = configReader.init_prop("acp.properties");	
			  LOGGER.log(Level.INFO, "Environment value set as: ACP");
		  } 
		  return properties; 		  
	}
	
	public void launchapp() throws InterruptedException{
		try 
		{
			getenvproperties();
		
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(properties.getProperty("appurl"));
			driver.manage().window().maximize();
			ngDriver.waitForAngularRequestsToFinish();
			Allure.addAttachment("Application Login page launched successfully "+properties.getProperty("appurl"), new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			LOGGER.log(Level.INFO, "Application Login page launched successfully "+properties.getProperty("appurl"));
			WebDriverWait wait = new WebDriverWait(driver, 5);  
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("user-name")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
				
	}
	
	public void userNameDisplay(){
		try
		{			
			WebElement username = driver.findElement(CommonObjRepo.userName);
			if(username.isDisplayed()==true)
			{
				LOGGER.log(Level.INFO, "User name field is displayed successfully");
				Allure.addAttachment("User name field is displayed successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			}
			else
			{
				System.exit(1);
			}
		}	
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterUserName() throws InterruptedException{	
		try
		{
			WebElement username = driver.findElement(CommonObjRepo.userName);
			enterByElement(username, Constants.getUsername(), driver);
			LOGGER.log(Level.INFO, "User name field is entered successfully");
			Allure.addAttachment("User name is entered successfully "+Constants.getUsername(), new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterPassword(){
		try 
		{			
			WebElement password = driver.findElement(CommonObjRepo.password);
			enterByElement(password, Constants.getPassword(), driver);
			LOGGER.log(Level.INFO, "Password is entered successfully");
			Allure.addAttachment("Password is entered successfully "+"********", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterusernameandpwdusingexcel(String TCID){		
		try{			
			ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", properties.getProperty("WorkBookName"));			
			testdata.setDatasheetName("GeneralData");
											
			int rowNo = testdata.getRowCount(TCID, 0);
																				
			String username = testdata.getValue(rowNo, "UserName");
			String password = testdata.getValue(rowNo, "Password");
				
			WebElement UserName = driver.findElement(CommonObjRepo.userName);
			WebElement Password = driver.findElement(CommonObjRepo.password);
			
			enterByElement(UserName, username, driver);
			enterByElement(Password, password, driver);			
			
			LOGGER.log(Level.INFO, "Username is entered successfully as "+ username);
			LOGGER.log(Level.INFO, "Password is entered successfully as "+ "*******");
			Allure.addAttachment("Username is enterd successfully as  "+ username, new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			Allure.addAttachment("Password is enterd successfully as  "+ "***********", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
		}
		catch(Exception e)
		{
			e.fillInStackTrace();
		}		
	}
	
	public void enterusernameandpwdusingfillo(String TCID) throws InterruptedException, FilloException{		
		try{				
			String username=null;
			String password=null;
			
			Fillo fillo=new Fillo();
			Connection connection=fillo.getConnection("./src/test/resources/testData/"+properties.getProperty("WorkBookName")+".xls");
			String strQuery="Select * from GeneralData where TCID = '"+TCID+"'";
			Recordset recordset=null;
			recordset=connection.executeQuery(strQuery);			
			while(recordset.next()){
				username = recordset.getField("UserName");
				password = recordset.getField("Password");				
			}			 
			WebElement UserName = driver.findElement(CommonObjRepo.userName);
			WebElement Password = driver.findElement(CommonObjRepo.password);
			
			enterByElement(UserName, username, driver);
			enterByElement(Password, password, driver);			
						
			LOGGER.log(Level.INFO, "Username is entered successfully as "+ username);
			LOGGER.log(Level.INFO, "Password is entered successfully as "+ "*******");					
			Allure.addAttachment("Username is enterd successfully as  "+ username, new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			Allure.addAttachment("Password is enterd successfully as  "+ "***********", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
						
			recordset.close();
			connection.close();
		}
		catch(Exception e)
		{				
			e.fillInStackTrace();
		}				
	}
	
	public void enterusernameandpwdusingjson(String TCID){
		
		try{
							
			jsonObject = ReadJson.readjson("./src/test/resources/testData/GeneralData.json");
			
			JSONArray generalDataList = (JSONArray) jsonObject.get(TCID);
			 
			@SuppressWarnings("unchecked")
			Iterator<JSONObject> iterator = generalDataList.iterator();
			while (iterator.hasNext()) {
				LOGGER.log(Level.INFO, "Iterator value:" + iterator.next());				
			}
			
			for (Object o : generalDataList) {
	            JSONObject generalData = (JSONObject) o;

	            String username = (String) generalData.get("UserName");
	            String password = (String) generalData.get("Password");	                  		
				
	            WebElement UserName = driver.findElement(CommonObjRepo.userName);
				WebElement Password = driver.findElement(CommonObjRepo.password);
				
				enterByElement(UserName, username, driver);
				enterByElement(Password, password, driver);			
												
				LOGGER.log(Level.INFO, "Username is entered successfully as "+ username);
				LOGGER.log(Level.INFO, "Password is entered successfully as "+ "*******");
				Allure.addAttachment("Username is enterd successfully as  "+ username, new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
				Allure.addAttachment("Password is enterd successfully as  "+ "***********", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
			}
		}
		catch(Exception e)
		{				
			e.fillInStackTrace();
		}		
	}

	public void clickLoginButton(){
		try
		{
			WebElement loginButton = driver.findElement(CommonObjRepo.loginButton);
			clickByElement(loginButton, driver);
			LOGGER.log(Level.INFO, "Login button is clicked successfully");
			Allure.addAttachment("Login button clicked successfully ", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
		
	public void clickLogoutButton(){
		try
		{
			WebElement menubutton = driver.findElement(CommonObjRepo.menubutton);
			WebElement logoutBtn = driver.findElement(CommonObjRepo.logoutBtn);
			//customSleepOne();
			clickByElement(menubutton, driver);
			//driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			clickByElement(logoutBtn, driver);
			LOGGER.log(Level.INFO, "Logout button is clicked successfully");
			Allure.addAttachment("Logout button clicked successfully ", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
