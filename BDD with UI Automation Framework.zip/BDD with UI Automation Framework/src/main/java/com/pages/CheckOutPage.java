package com.pages;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.objrepository.CheckOutPageObjRepo;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.qa.util.ConfigReader;
import com.qa.util.GenericWrappers;

import helper.WaitHelper;
import io.qameta.allure.Allure;
import com.qa.util.ExcelDataAccess;
import com.qa.util.FrameworkException;
import com.qa.util.ReadJson;

public class CheckOutPage extends GenericWrappers {
	private WebDriver driver;
	public static NgWebDriver ngDriver;
	WaitHelper waitHelper;
	private final static Logger LOGGER = 
            Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	JSONObject jsonObject = null;

	String FirstName;
    String LastName;
    String PostalZip;
    
	ConfigReader configReader = new ConfigReader();
	    		
	public CheckOutPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		ngDriver = new NgWebDriver((JavascriptExecutor) driver);		
	}
	UIConfig uiconfig = new UIConfig(driver);
	public Properties properties = uiconfig.getenvproperties(); 	
	
	public void enterOrderDataUsingJson(){	
		
		try {		
			jsonObject = ReadJson.readjson("/src/test/resources/testData/SingleTestData.json");
					
			JSONArray orderList = (JSONArray) jsonObject.get("Order1");
			 
			@SuppressWarnings("unchecked")
			Iterator<JSONObject> iterator = orderList.iterator();
			while (iterator.hasNext()) {
				LOGGER.log(Level.INFO, "Iteration No: "+iterator.next());					
			}
			
			for (Object o : orderList) {
	            JSONObject Senders = (JSONObject) o;
	
	            FirstName = (String) Senders.get("FirstName");
	            LastName = (String) Senders.get("LastName");
	            PostalZip = (String) Senders.get("PostalZip");                 
	            
	            //WebDriverWait wait = new WebDriverWait(driver,5);
	            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstName")));
	            WebElement firstname = driver.findElement(CheckOutPageObjRepo.firstname);
	            WebElement lastname = driver.findElement(CheckOutPageObjRepo.lastname);
	            WebElement postalcode = driver.findElement(CheckOutPageObjRepo.postalcode);
	            
	            enterByElement(firstname, FirstName, driver);
	            firstname.sendKeys(Keys.TAB);
	            enterByElement(lastname, LastName, driver);
	            lastname.sendKeys(Keys.TAB);
	            enterByElement(postalcode, PostalZip, driver);          	            
			}      
		} catch (Exception e) {				
			throw new FrameworkException("Checkout Page", "Error in entering the mandatory fields using Json");
			//e.fillInStackTrace();
		}		
	}
	
	public void enterOrderDataUsingExcel(){	
		
		try {
			ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", "TestData");			
			testdata.setDatasheetName("TestData");
			
			int nTestInstances = testdata.getLastRowNum();
			
			for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
				
				FirstName = testdata.getValue(currentTestInstance, "FirstName");
				LastName = testdata.getValue(currentTestInstance, "LastName");
				PostalZip = testdata.getValue(currentTestInstance, "PostalZip");			
			}
		        
	        //WebDriverWait wait = new WebDriverWait(driver,5);
	        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstName")));
			WebElement firstname = driver.findElement(CheckOutPageObjRepo.firstname);
            WebElement lastname = driver.findElement(CheckOutPageObjRepo.lastname);
            WebElement postalcode = driver.findElement(CheckOutPageObjRepo.postalcode);
            
            enterByElement(firstname, FirstName, driver);
            firstname.sendKeys(Keys.TAB);
            enterByElement(lastname, LastName, driver);
            lastname.sendKeys(Keys.TAB);
            enterByElement(postalcode, PostalZip, driver);    
		
		} catch (Exception e) {				
		throw new FrameworkException("Checkout Page", "Error in entering the mandatory fields using Excel");
		//e.fillInStackTrace();
		}      
	}
	
	public void enterOrderDataUsingFillo(){	
		
		try {			
				Fillo fillo=new Fillo();
				Connection connection=fillo.getConnection("./src/test/resources/testData/"+"TestData"+".xls");
				String strQuery="Select * from TestData";
				Recordset recordset=connection.executeQuery(strQuery);
				 
				while(recordset.next()){
					FirstName = recordset.getField("FirstName");
					LastName = recordset.getField("LastName");
					PostalZip = recordset.getField("PostalZip");
				
				}
				 
				//WebDriverWait wait = new WebDriverWait(driver,5);
		        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("firstName")));
				WebElement firstname = driver.findElement(CheckOutPageObjRepo.firstname);
	            WebElement lastname = driver.findElement(CheckOutPageObjRepo.lastname);
	            WebElement postalcode = driver.findElement(CheckOutPageObjRepo.postalcode);
	            
	            enterByElement(firstname, FirstName, driver);
	            firstname.sendKeys(Keys.TAB);
	            enterByElement(lastname, LastName, driver);
	            lastname.sendKeys(Keys.TAB);
	            enterByElement(postalcode, PostalZip, driver);      
		        
				recordset.close();
				connection.close();	
				
		} catch (Exception e) {				
		throw new FrameworkException("Checkout Page", "Error in entering the mandatory fields using Fillo");
		//e.fillInStackTrace();
		}      
	}

	public void enterOrderDataUsingMultipeInputs(String Input){

		try {
			if(Input.contains("Excel"))
				enterOrderDataUsingExcel();
			else if(Input.contains("Json"))
				enterOrderDataUsingJson();
			else
				enterOrderDataUsingFillo();

		} catch (Exception e) {
			throw new FrameworkException("Checkout Page", "Error in entering the mandatory fields using Fillo");
			//e.fillInStackTrace();
		}
	}
	
	// Method to click on 'Continue' button
	   public void clickOnContinue() {
			try {	
				WebElement continuebtn = driver.findElement(CheckOutPageObjRepo.continuebtn);
				clickByElement(continuebtn, driver);
				LOGGER.log(Level.INFO, "Clicked on Continue button successfully");
				Allure.addAttachment("Clicked on Continue button successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
				 
			} catch (Exception e) {				
				throw new FrameworkException("CheckOut", "Error in clicking on 'Continue' button");
				//e.fillInStackTrace();
			}
		}

	// Method to click on 'Finish' button
		public void clickOnFinish() {				
			try {						
				WebElement finishbtn = driver.findElement(CheckOutPageObjRepo.finishbtn);
				scrollToTarget(finishbtn);
				clickByElement(finishbtn, driver);
				LOGGER.log(Level.INFO, "Clicked on Finish button successfully");				
				Allure.addAttachment("Outgoing Order clicked successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
				 
			} catch (Exception e) {				
				throw new FrameworkException("CheckOut", "Error in clicking on 'Finish' button");
				//e.fillInStackTrace();
			}
		}		
		
		
		public void enterMultipleOrderDataUsingExcel(String TCID) { 
			  try {
					  ExcelDataAccess testdata = new ExcelDataAccess("./src/test/resources/testData/", properties.getProperty("WorkBookName"));
					  testdata.setDatasheetName("MultipleTestData");
					  
					  int rowNo = testdata.getRowCount(TCID, 0);
					  
					  FirstName = testdata.getValue(rowNo, "FirstName"); 
					  LastName = testdata.getValue(rowNo, "LastName");
					  PostalZip = testdata.getValue(rowNo, "PostalZip");
					  				  
					  enterdetails(FirstName, LastName, PostalZip);
		  
			  } catch (Exception e) { 
			  throw new FrameworkException("CheckOut", "Error in entering data in Check Out Page");
		  //e.fillInStackTrace(); } 
			  }
		 }
		  
		 public void enterMultipleOrderDataUsingFillo(String TCID) { 
			 try {
		 		  
					  Fillo fillo=new Fillo(); 
					  Connection connection=fillo.getConnection("./src/test/resources/testData/"+properties.getProperty("WorkBookName")+".xls"); String
					  strQuery="Select * from MultipleTestData where TCID = '"+TCID+"'"; 
					  Recordset recordset=connection.executeQuery(strQuery);
					  
					  while(recordset.next()){
						  FirstName = recordset.getField("FirstName");
						  LastName = recordset.getField("LastName"); 
						  PostalZip = recordset.getField("PostalZip"); 
					  }
					  
					  enterdetails(FirstName, LastName, PostalZip);
					  recordset.close(); 
					  connection.close();
		  
			  } catch (Exception e) { 
				  throw new FrameworkException("CheckOut", "Error in entering data in Check Out Page");
		  //e.fillInStackTrace(); 
			  }
		   }

	public void enterMultipleOrderDataUsingJson(String TCID){
		try {

			jsonObject = ReadJson.readjson("./src/test/resources/testData/MultipleTestData.json");
			JSONArray testDataList = (JSONArray) jsonObject.get(TCID);

			@SuppressWarnings("unchecked")
			Iterator<JSONObject> iterator = testDataList.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}

			for (Object o : testDataList) {
				JSONObject testData = (JSONObject) o;
				FirstName = (String) testData.get("FirstName");
				LastName = (String) testData.get("LastName");
				PostalZip = (String) testData.get("PostalZip");
			}

			enterdetails(FirstName, LastName, PostalZip);

		} catch(Exception e) {
			throw new FrameworkException("CheckOut", "Error in entering data in Check Out Page");
		}
	}

	public void enterMultipleOrderDataUsingMultipleInputs(String TCID,String Input){
		try {
			if(Input.contains("Excel"))
					enterMultipleOrderDataUsingExcel(TCID);
			else if(Input.contains("Json"))
					enterMultipleOrderDataUsingJson(TCID);
			else
					enterMultipleOrderDataUsingFillo(TCID);

		} catch(Exception e) {
			throw new FrameworkException("CheckOut", "Error in entering data in Check Out Page");
		}
	}


		  
	private void enterdetails(String firstName, String lastName, String postalZip) throws IOException {
			  
			  try {					      
				  	WebElement FirstName = driver.findElement(CheckOutPageObjRepo.firstname);
		            WebElement LastName = driver.findElement(CheckOutPageObjRepo.lastname);
		            WebElement PostalCode = driver.findElement(CheckOutPageObjRepo.postalcode);
		            
					  if (!firstName.isEmpty()) {
					  
						  enterByElement(FirstName, firstName, driver);
						  driver.findElement(CheckOutPageObjRepo.firstname).sendKeys(Keys.TAB);
					      Allure.addAttachment("First Name entered successfully as: "+ firstName, new ByteArrayInputStream(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES)));
					  
					  }
					  
					  if (!lastName.isEmpty()) {
						  
						  enterByElement(LastName, lastName, driver);
						  driver.findElement(CheckOutPageObjRepo.lastname).sendKeys(Keys.TAB);
					      Allure.addAttachment("Last Name entered successfully as: "+ lastName, new ByteArrayInputStream(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES)));
					  
					  }
					  
					  if (!postalZip.isEmpty()) {
						  
						  enterByElement(PostalCode, postalZip, driver);
						  driver.findElement(CheckOutPageObjRepo.postalcode).sendKeys(Keys.TAB);
					      Allure.addAttachment("Postal Zip entered successfully as: "+ postalZip, new ByteArrayInputStream(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES)));
					  
					  }					  
					   
			  } catch(Exception e) {
				  e.fillInStackTrace();
			  }
		}		 
				
		public void verifyTheOrderPlacedMessage() {
			try {
				
				WebElement successmsg = driver.findElement(CheckOutPageObjRepo.successmsg);
				
				scrollUp();
				customSleepOne();
				String ordersuccessmsg = successmsg.getText();
				
				if(ordersuccessmsg.contains("THANK YOU"))
				{
					Allure.addAttachment("Order status verified successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
					LOGGER.log(Level.INFO, "Order status is displayed as '"+ordersuccessmsg+"' after placing the order");
				}
				else
				{
					Allure.addAttachment("Order status is Not verified successfully", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
					LOGGER.log(Level.WARNING, "Order status is Not displayed after placing the order");
				}				
			}catch (Exception e) {
				throw new FrameworkException("CheckOut Complete", "Error in verifying the order status message");
				//e.fillInStackTrace();
			}
		}		
}
