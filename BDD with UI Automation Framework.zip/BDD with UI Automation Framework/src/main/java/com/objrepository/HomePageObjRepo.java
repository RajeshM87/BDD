package com.objrepository;

import org.openqa.selenium.By;

public class HomePageObjRepo {
	
	public static final By productstitle = By.xpath("//span[@class='title']");
	public static final By addtocart = By.cssSelector("button[name='add-to-cart-sauce-labs-backpack']");
	public static final By shoppingcart = By.xpath("//*[@id='shopping_cart_container']/a[@class='shopping_cart_link']");
	
	/*
	 * @FindBy(xpath ="//span[@class='title']") public WebElement productstitle;
	 * 
	 * @FindBy(css ="button[name='add-to-cart-sauce-labs-backpack']") public
	 * WebElement addtocart;
	 * 
	 * @FindBy(xpath =
	 * "//*[@id='shopping_cart_container']/a[@class='shopping_cart_link']") public
	 * WebElement shoppingcart;
	 */
		
}
