package com.objrepository;

import org.openqa.selenium.By;

public class ShoppingCartPageObjRepo {
	
	public static final By checkout = By.id("checkout");
	
	/*
	 * @FindBy(id = "checkout") public WebElement checkout;
	 */
		
}
